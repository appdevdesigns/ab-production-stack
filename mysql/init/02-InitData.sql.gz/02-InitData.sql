# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.22)
# Database: test_docker
# Generation Time: 2018-10-31 06:33:10 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

USE site;

# Dump of table appbuilder_application
# ------------------------------------------------------------

CREATE TABLE `appbuilder_application` (
  `json` longtext,
  `name` varchar(255) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table appbuilder_application_trans
# ------------------------------------------------------------

CREATE TABLE `appbuilder_application_trans` (
  `abapplication` int(11) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `description` longtext,
  `language_code` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `appbuilder_definition` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `json` longtext DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `appbuilder_definition` WRITE;
/*!40000 ALTER TABLE `appbuilder_definition` DISABLE KEYS */;

INSERT INTO `appbuilder_definition` (`id`, `name`, `type`, `json`, `createdAt`, `updatedAt`)
VALUES
  ('0653f627-fcc9-4def-af91-127fb1690d61','SCOPE->objectIds','field','{\"id\":\"0653f627-fcc9-4def-af91-127fb1690d61\",\"type\":\"field\",\"key\":\"json\",\"icon\":\"font\",\"isImported\":0,\"columnName\":\"objectIds\",\"settings\":{\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0},\"translations\":[{\"language_code\":\"en\",\"label\":\"Objects\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35'),
  ('4fd9e0e9-cab1-4077-b7b1-34f98d061d7e','SCOPE->name','field','{\"id\":\"4fd9e0e9-cab1-4077-b7b1-34f98d061d7e\",\"type\":\"field\",\"key\":\"string\",\"icon\":\"font\",\"isImported\":0,\"columnName\":\"name\",\"settings\":{\"supportMultilingual\":1,\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0,\"default\":\"\",\"translations\":[{\"language_code\":\"en\",\"default\":\"\"}]},\"translations\":[{\"language_code\":\"en\",\"label\":\"Name\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35'),
  ('7b98a147-b051-44c0-8d90-8c8d5aeda453','SCOPE->filter','field','{\"id\":\"7b98a147-b051-44c0-8d90-8c8d5aeda453\",\"type\":\"field\",\"key\":\"json\",\"icon\":\"font\",\"isImported\":0,\"columnName\":\"filter\",\"settings\":{\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0},\"translations\":[{\"language_code\":\"en\",\"label\":\"Filter\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35'),
  ('8778cf3a-774b-4ad4-88a7-6c5a9491c224','SCOPE->description','field','{\"id\":\"8778cf3a-774b-4ad4-88a7-6c5a9491c224\",\"type\":\"field\",\"key\":\"LongText\",\"icon\":\"align-right\",\"isImported\":0,\"columnName\":\"description\",\"settings\":{\"supportMultilingual\":1,\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0,\"default\":\"\",\"translations\":[{\"language_code\":\"en\",\"default\":\"\"}]},\"translations\":[{\"language_code\":\"en\",\"label\":\"Description\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35'),
  ('af10e37c-9b3a-4dc6-a52a-85d52320b659','SCOPE','object','{\n        \"id\": \"af10e37c-9b3a-4dc6-a52a-85d52320b659\",\n        \"type\": \"object\",\n        \"name\": \"SCOPE\",\n        \"labelFormat\": \"\",\n        \"isImported\": 0,\n        \"isExternal\": 0,\n        \"tableName\": \"AB_SYSTEM_SCOPE\",\n        \"primaryColumnName\": \"uuid\",\n        \"transColumnName\": \"\",\n        \"urlPath\": \"\",\n        \"importFromObject\": \"\",\n        \"objectWorkspace\": {\n            \"sortFields\": [],\n            \"filterConditions\": [],\n            \"frozenColumnID\": \"\",\n            \"hiddenFields\": []\n        },\n        \"isSystemObject\": true,\n        \"translations\": [\n            {\n                \"language_code\": \"en\",\n                \"label\" : \"Scope\"\n            }\n        ],\n        \"fieldIDs\": [\n            \"e3670083-befb-4139-ae40-c375efe8da4e\",\n            \"4fd9e0e9-cab1-4077-b7b1-34f98d061d7e\",\n            \"8778cf3a-774b-4ad4-88a7-6c5a9491c224\",\n            \"b87cd56b-ae27-42b7-aba8-afd1bad2a5ef\",\n            \"0653f627-fcc9-4def-af91-127fb1690d61\",\n            \"7b98a147-b051-44c0-8d90-8c8d5aeda453\",\n            \"de700f82-6afb-4ab0-903a-480ba173b0b3\"\n        ]\n    }',NULL,NULL),
  ('b87cd56b-ae27-42b7-aba8-afd1bad2a5ef','SCOPE->createdBy','field','{\"id\":\"b87cd56b-ae27-42b7-aba8-afd1bad2a5ef\",\"type\":\"field\",\"key\":\"user\",\"icon\":\"user-o\",\"isImported\":0,\"columnName\":\"createdBy\",\"settings\":{\"isMultiple\":0,\"isShowProfileImage\":0,\"isCurrentUser\":1,\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0,\"editable\":1,\"isShowUsername\":1},\"translations\":[{\"language_code\":\"en\",\"label\":\"Created By\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35'),
  ('de700f82-6afb-4ab0-903a-480ba173b0b3','SCOPE->allowAll','field','{\"id\":\"de700f82-6afb-4ab0-903a-480ba173b0b3\",\"type\":\"field\",\"key\":\"boolean\",\"icon\":\"check-square-o\",\"isImported\":0,\"columnName\":\"allowAll\",\"settings\":{\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0,\"default\":0},\"translations\":[{\"language_code\":\"en\",\"label\":\"Allow All\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35'),
  ('e3670083-befb-4139-ae40-c375efe8da4e','SCOPE->Role','field','{\n   \"id\": \"e3670083-befb-4139-ae40-c375efe8da4e\",\n   \"key\":\"connectObject\",\n   \"label\": \"Roles\",\n   \"columnName\": \"roles\",\n   \"settings\": {\n      \"linkObject\": \"c33692f3-26b7-4af3-a02e-139fb519296d\",\n      \"linkType\": \"many\",\n      \"linkViaType\": \"many\",\n      \"linkColumn\": \"4585d5cb-0eea-461d-a326-61187c88520f\",\n      \"isSource\": 1\n   }\n}',NULL,NULL),
  ('07e6a725-aba0-42e6-9b38-984fef7e8274','ROLE->description','field','{\"id\":\"07e6a725-aba0-42e6-9b38-984fef7e8274\",\"type\":\"field\",\"key\":\"LongText\",\"icon\":\"align-right\",\"isImported\":0,\"columnName\":\"description\",\"settings\":{\"supportMultilingual\":1,\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0,\"default\":\"\",\"translations\":[{\"language_code\":\"en\",\"default\":\"\"}]},\"translations\":[{\"language_code\":\"en\",\"label\":\"Description\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35'),
  ('4585d5cb-0eea-461d-a326-61187c88520f','ROLE->Scopes','field','{\n   \"id\": \"4585d5cb-0eea-461d-a326-61187c88520f\",\n   \"key\": \"connectObject\",\n   \"label\": \"Scopes\",\n   \"columnName\": \"scopes\",\n   \"settings\": {\n      \"linkObject\": \"af10e37c-9b3a-4dc6-a52a-85d52320b659\",\n      \"linkType\": \"many\",\n      \"linkViaType\": \"many\",\n      \"linkColumn\": \"e3670083-befb-4139-ae40-c375efe8da4e\",\n      \"isSource\": 0\n   }\n}',NULL,NULL),
  ('9d6d77be-eef9-46c5-b7f2-df44d44d9e61','ROLE->users','field','{\"id\":\"9d6d77be-eef9-46c5-b7f2-df44d44d9e61\",\"type\":\"field\",\"key\":\"user\",\"icon\":\"user-o\",\"isImported\":0,\"columnName\":\"users\",\"settings\":{\"isMultiple\":1,\"isShowProfileImage\":0,\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0,\"editable\":1,\"isCurrentUser\":0,\"isShowUsername\":1},\"translations\":[{\"language_code\":\"en\",\"label\":\"Users\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35'),
  ('c33692f3-26b7-4af3-a02e-139fb519296d','ROLE','object','{\n        \"id\": \"c33692f3-26b7-4af3-a02e-139fb519296d\",\n        \"type\": \"object\",\n        \"name\": \"ROLE\",\n        \"labelFormat\": \"\",\n        \"isImported\": 0,\n        \"isExternal\": 0,\n        \"tableName\": \"AB_SYSTEM_ROLE\",\n        \"primaryColumnName\": \"uuid\",\n        \"transColumnName\": \"\",\n        \"urlPath\": \"\",\n        \"importFromObject\": \"\",\n        \"objectWorkspace\": {\n            \"sortFields\": [],\n            \"filterConditions\": [],\n            \"frozenColumnID\": \"\",\n            \"hiddenFields\": []\n        },\n        \"isSystemObject\": true,\n        \"translations\": [\n            {\n                \"language_code\": \"en\",\n                \"label\" : \"Role\"\n            }\n        ],\n        \"fieldIDs\": [\n            \"4585d5cb-0eea-461d-a326-61187c88520f\",\n            \"f1fccbbf-f226-4e9e-aa6a-119f8cc309b6\",\n            \"07e6a725-aba0-42e6-9b38-984fef7e8274\",\n            \"9d6d77be-eef9-46c5-b7f2-df44d44d9e61\"\n        ]\n    }',NULL,NULL),
  ('f1fccbbf-f226-4e9e-aa6a-119f8cc309b6','ROLE->name','field','{\"id\":\"f1fccbbf-f226-4e9e-aa6a-119f8cc309b6\",\"type\":\"field\",\"key\":\"string\",\"icon\":\"font\",\"isImported\":0,\"columnName\":\"name\",\"settings\":{\"supportMultilingual\":1,\"showIcon\":1,\"required\":1,\"width\":0,\"unique\":0,\"default\":\"\",\"translations\":[{\"language_code\":\"en\",\"default\":\"\"}]},\"translations\":[{\"language_code\":\"en\",\"label\":\"Name\"}]}','2020-04-24 06:29:35','2020-04-24 06:29:35');

/*!40000 ALTER TABLE `appbuilder_definition` ENABLE KEYS */;
UNLOCK TABLES;



# Dump of table appbuilder_qr_appuser
# ------------------------------------------------------------

CREATE TABLE `appbuilder_qr_appuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteuser` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `token` mediumtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `siteuser` (`siteuser`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table appbuilder_relay_appuser
# ------------------------------------------------------------

CREATE TABLE `appbuilder_relay_appuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `relayUser` int(11) DEFAULT NULL,
  `aes` mediumtext,
  `appUUID` mediumtext,
  `appID` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table appbuilder_relay_user
# ------------------------------------------------------------

CREATE TABLE `appbuilder_relay_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteuser_guid` varchar(255) DEFAULT NULL,
  `user` mediumtext,
  `publicAuthToken` mediumtext,
  `rsa_public_key` mediumtext,
  `rsa_private_key` mediumtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `siteuser_guid` (`siteuser_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table en_notification
# ------------------------------------------------------------

CREATE TABLE `en_notification` (
  `notificationTitle` varchar(255) DEFAULT NULL,
  `emailSubject` longtext,
  `fromName` varchar(255) DEFAULT NULL,
  `fromEmail` varchar(255) DEFAULT NULL,
  `setupType` varchar(255) DEFAULT NULL,
  `eventTrigger` varchar(255) DEFAULT NULL,
  `startFrom` date DEFAULT NULL,
  `emailFrequency` varchar(255) DEFAULT NULL,
  `repeatUntil` date DEFAULT NULL,
  `nextNotificationDate` date DEFAULT NULL,
  `templateDesignId` int(11) DEFAULT NULL,
  `recipientId` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table en_notification_log
# ------------------------------------------------------------

CREATE TABLE `en_notification_log` (
  `notificationId` int(11) DEFAULT NULL,
  `sendDate` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `log` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table en_recipient
# ------------------------------------------------------------

CREATE TABLE `en_recipient` (
  `title` varchar(255) DEFAULT NULL,
  `recipients` longtext,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table en_template_design
# ------------------------------------------------------------

CREATE TABLE `en_template_design` (
  `templateTitle` varchar(255) DEFAULT NULL,
  `templateBody` longtext,
  `templateType` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table op_config_area
# ------------------------------------------------------------

CREATE TABLE `op_config_area` (
  `key` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `isDefault` tinyint(1) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `op_config_area` WRITE;
/*!40000 ALTER TABLE `op_config_area` DISABLE KEYS */;

INSERT INTO `op_config_area` (`key`, `icon`, `isDefault`, `weight`, `id`, `createdAt`, `updatedAt`)
VALUES
	('site-default-admin','fa-cogs',0,0,1,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	('site-default-appbuilder','fa-edit',0,0,2,'2018-10-31 12:46:29','2018-10-31 12:46:29');

/*!40000 ALTER TABLE `op_config_area` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table op_config_area_trans
# ------------------------------------------------------------

CREATE TABLE `op_config_area_trans` (
  `area` int(11) DEFAULT NULL,
  `language_code` varchar(10) DEFAULT NULL,
  `label` varchar(100) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `op_config_area_trans` WRITE;
/*!40000 ALTER TABLE `op_config_area_trans` DISABLE KEYS */;

INSERT INTO `op_config_area_trans` (`area`, `language_code`, `label`, `id`, `createdAt`, `updatedAt`)
VALUES
	(1,'en','Administration',1,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'ko','[ko]Administration',2,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'zh-hans','[zh-hans]Administration',3,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'th','[th]Administration',4,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(2,'ko','[ko]AppBuilder',5,'2018-10-31 12:46:29','2018-10-31 12:46:29'),
	(2,'en','AppBuilder',6,'2018-10-31 12:46:29','2018-10-31 12:46:29'),
	(2,'th','[th]AppBuilder',7,'2018-10-31 12:46:29','2018-10-31 12:46:29'),
	(2,'zh-hans','[zh-hans]AppBuilder',8,'2018-10-31 12:46:29','2018-10-31 12:46:29');

/*!40000 ALTER TABLE `op_config_area_trans` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table op_config_tool
# ------------------------------------------------------------

CREATE TABLE `op_config_tool` (
  `key` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `isDefault` tinyint(1) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `isController` tinyint(1) DEFAULT NULL,
  `options` longtext,
  `weight` int(11) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `op_config_tool` WRITE;
/*!40000 ALTER TABLE `op_config_tool` DISABLE KEYS */;

INSERT INTO `op_config_tool` (`key`, `icon`, `isDefault`, `controller`, `isController`, `options`, `weight`, `id`, `createdAt`, `updatedAt`)
VALUES
	('opsportal.rbac','fa-users',0,'RBAC',1,'{}',0,1,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	('appbuilder.designer','fa-object-group',0,'BuildApp',1,'{}',0,2,'2018-10-31 12:46:29','2018-10-31 12:46:29');

/*!40000 ALTER TABLE `op_config_tool` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table op_config_tool_trans
# ------------------------------------------------------------

CREATE TABLE `op_config_tool_trans` (
  `tool` int(11) DEFAULT NULL,
  `language_code` varchar(10) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `op_config_tool_trans` WRITE;
/*!40000 ALTER TABLE `op_config_tool_trans` DISABLE KEYS */;

INSERT INTO `op_config_tool_trans` (`tool`, `language_code`, `label`, `id`, `createdAt`, `updatedAt`)
VALUES
	(1,'en','Ops Portal Permissions',1,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'ko','[ko]Ops Portal Permissions',2,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'zh-hans','[zh-hans]Ops Portal Permissions',3,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'th','[th]Ops Portal Permissions',4,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(2,'en','App Builder',5,'2018-10-31 12:46:29','2018-10-31 12:46:29'),
	(2,'ko','[ko]App Builder',6,'2018-10-31 12:46:29','2018-10-31 12:46:29'),
	(2,'zh-hans','[zh-hans]App Builder',7,'2018-10-31 12:46:29','2018-10-31 12:46:29'),
	(2,'th','[th]App Builder',8,'2018-10-31 12:46:29','2018-10-31 12:46:29');

/*!40000 ALTER TABLE `op_config_tool_trans` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table op_config_tooldefinition
# ------------------------------------------------------------

CREATE TABLE `op_config_tooldefinition` (
  `key` varchar(255) DEFAULT NULL,
  `permissions` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `isController` tinyint(1) DEFAULT NULL,
  `options` longtext,
  `version` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `op_config_tooldefinition` WRITE;
/*!40000 ALTER TABLE `op_config_tooldefinition` DISABLE KEYS */;

INSERT INTO `op_config_tooldefinition` (`key`, `permissions`, `icon`, `label`, `controller`, `isController`, `options`, `version`, `id`, `createdAt`, `updatedAt`)
VALUES
	('opsportal.rbac','opsportal.rbac.view','fa-users','Ops Portal Permissions','RBAC',1,'{}','0',1,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	('appbuilder.designer','appbuilder.designer.view','fa-object-group','App Builder','BuildApp',1,'{}','0',2,'2018-10-31 12:46:29','2018-10-31 12:46:29');

/*!40000 ALTER TABLE `op_config_tooldefinition` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table op_fileupload
# ------------------------------------------------------------

CREATE TABLE `op_fileupload` (
  `uuid` varchar(255) DEFAULT NULL,
  `appKey` varchar(255) DEFAULT NULL,
  `permission` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `pathFile` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `info` longtext,
  `uploadedBy` int(11) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table op_imageupload
# ------------------------------------------------------------

CREATE TABLE `op_imageupload` (
  `uuid` varchar(255) DEFAULT NULL,
  `app_key` varchar(255) DEFAULT NULL,
  `permission` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table op_opview
# ------------------------------------------------------------

CREATE TABLE `op_opview` (
  `key` varchar(255) DEFAULT NULL,
  `objects` longtext,
  `controller` longtext,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table opconfigarea_tools__opconfigtool_areas
# ------------------------------------------------------------

CREATE TABLE `opconfigarea_tools__opconfigtool_areas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `opconfigarea_tools` int(11) DEFAULT NULL,
  `opconfigtool_areas` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `opconfigarea_tools__opconfigtool_areas` WRITE;
/*!40000 ALTER TABLE `opconfigarea_tools__opconfigtool_areas` DISABLE KEYS */;

INSERT INTO `opconfigarea_tools__opconfigtool_areas` (`id`, `opconfigarea_tools`, `opconfigtool_areas`)
VALUES
	(1,1,1),
	(2,2,2);

/*!40000 ALTER TABLE `opconfigarea_tools__opconfigtool_areas` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table opconfigtool_permissions__permissionaction_tools
# ------------------------------------------------------------

CREATE TABLE `opconfigtool_permissions__permissionaction_tools` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `opconfigtool_permissions` int(11) DEFAULT NULL,
  `permissionaction_tools` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `opconfigtool_permissions__permissionaction_tools` WRITE;
/*!40000 ALTER TABLE `opconfigtool_permissions__permissionaction_tools` DISABLE KEYS */;

INSERT INTO `opconfigtool_permissions__permissionaction_tools` (`id`, `opconfigtool_permissions`, `permissionaction_tools`)
VALUES
	(1,1,6),
	(2,2,8);

/*!40000 ALTER TABLE `opconfigtool_permissions__permissionaction_tools` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table permission_scope__permissionscope_permission
# ------------------------------------------------------------

CREATE TABLE `permission_scope__permissionscope_permission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `permission_scope` int(11) DEFAULT NULL,
  `permissionscope_permission` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `permission_scope__permissionscope_permission` WRITE;
/*!40000 ALTER TABLE `permission_scope__permissionscope_permission` DISABLE KEYS */;

INSERT INTO `permission_scope__permissionscope_permission` (`id`, `permission_scope`, `permissionscope_permission`)
VALUES
	(1,1,1);

/*!40000 ALTER TABLE `permission_scope__permissionscope_permission` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table permissionaction_roles__permissionrole_actions
# ------------------------------------------------------------

CREATE TABLE `permissionaction_roles__permissionrole_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `permissionaction_roles` int(11) DEFAULT NULL,
  `permissionrole_actions` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `permissionaction_roles__permissionrole_actions` WRITE;
/*!40000 ALTER TABLE `permissionaction_roles__permissionrole_actions` DISABLE KEYS */;

INSERT INTO `permissionaction_roles__permissionrole_actions` (`id`, `permissionaction_roles`, `permissionrole_actions`)
VALUES
	(1,1,1),
	(2,2,1),
	(3,6,1),
	(4,7,1),
	(5,5,1),
	(6,8,1),
	(7,9,1);

/*!40000 ALTER TABLE `permissionaction_roles__permissionrole_actions` ENABLE KEYS */;
UNLOCK TABLES;




#
# process_manager
#

DROP TABLE IF EXISTS `appbuilder_processes`;

CREATE TABLE `appbuilder_processes` (
  `id` varchar(255) NOT NULL,
  `processID` varchar(255) DEFAULT NULL,
  `xmlDefinition` longtext DEFAULT NULL,
  `context` longtext DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `errorTasks` longtext DEFAULT NULL,
  `log` longtext DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `process_userform` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` text NOT NULL,
  `name` text DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending',
  `process` text NOT NULL,
  `definition` text NOT NULL,
  `responder` text DEFAULT NULL,
  `response` text DEFAULT NULL,
  `ui` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


# Dump of table Role_UserForm
# ------------------------------------------------------------

CREATE TABLE `Role_UserForm` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `Role` text NOT NULL,
  `UserForm` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


# Dump of table sessions
# ------------------------------------------------------------

CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int(11) unsigned NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table site_cookie_auth
# ------------------------------------------------------------

CREATE TABLE `site_cookie_auth` (
  `guid` varchar(255) DEFAULT NULL,
  `ticket` varchar(255) DEFAULT NULL,
  `expiration` datetime DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table site_error
# ------------------------------------------------------------

CREATE TABLE `site_error` (
  `message` longtext,
  `data` longtext,
  `reviewed` tinyint(1) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table site_multilingual_label
# ------------------------------------------------------------

CREATE TABLE `site_multilingual_label` (
  `language_code` varchar(25) DEFAULT NULL,
  `label_key` longtext,
  `label_label` longtext,
  `label_needs_translation` int(11) DEFAULT NULL,
  `label_context` longtext,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_multilingual_label` WRITE;
/*!40000 ALTER TABLE `site_multilingual_label` DISABLE KEYS */;

INSERT INTO `site_multilingual_label` (`language_code`, `label_key`, `label_label`, `label_needs_translation`, `label_context`, `id`, `createdAt`, `updatedAt`)
VALUES
	('en','opp.configuringTools','configuring Opsportal Tools:',0,'opsportal',1,'2018-10-31 12:46:21',NULL),
	('en','opp.menu','Menu',0,'opsportal',2,'2018-10-31 12:46:21',NULL),
	('en','opp.error','Error:',0,'opsportal',3,'2018-10-31 12:46:21',NULL),
	('en','opp.enterPortal','Enter the Portal',0,'opsportal',4,'2018-10-31 12:46:21',NULL),
	('en','opp.areaAdministration','Administration',0,'opsportal',5,'2018-10-31 12:46:21',NULL),
	('en','opp.toolPermissions','Permissions',0,'opsportal',6,'2018-10-31 12:46:21',NULL),
	('en','opp.areaProfile','Profile',0,'opsportal',7,'2018-10-31 12:46:21',NULL),
	('en','opp.toolProfile','Profile',0,'opsportal',8,'2018-10-31 12:46:21',NULL),
	('en','opp.toolObjectBuilder','Configure Objects',0,'opsportal',9,'2018-10-31 12:46:21',NULL),
	('en','opp.areaProcess','Process Tools',0,'opsportal',10,'2018-10-31 12:46:21',NULL),
	('en','opp.toolProcessApproval','Approvals',0,'opsportal',11,'2018-10-31 12:46:21',NULL),
	('en','opp.toolProcessTranslation','Translations',0,'opsportal',12,'2018-10-31 12:46:21',NULL),
	('en','opp.toolActivityReporting','Dashboard',0,'opsportal',13,'2018-10-31 12:46:21',NULL),
	('en','opp.areaFCFActivities','Activities',0,'opsportal',14,'2018-10-31 12:46:21',NULL),
	('en','opp.errorNoPermission','You don\'t have permission.  Ask your administrator to grant you access.',0,'opsportal',15,'2018-10-31 12:46:21',NULL),
	('en','rbac.user.confirmRemoveRole','This will remove role: %s',0,'opsportal',16,'2018-10-31 12:46:21',NULL),
	('en','rbac.user.enabled','Enabled',0,'opsportal',17,'2018-10-31 12:46:21',NULL),
	('en','rbac.Users','Users',0,'opsportal',18,'2018-10-31 12:46:21',NULL),
	('en','rbac.user.add','add',0,'opsportal',19,'2018-10-31 12:46:21',NULL),
	('en','rbac.user.selectSomeStuff','Select a role and one or more scopes for this assignment:',0,'opsportal',20,'2018-10-31 12:46:21',NULL),
	('en','rbac.Roles','Roles',0,'opsportal',21,'2018-10-31 12:46:21',NULL),
	('en','rbac.Scopes','Scopes',0,'opsportal',22,'2018-10-31 12:46:21',NULL),
	('en','rbac.Add','Add',0,'opsportal',23,'2018-10-31 12:46:21',NULL),
	('en','rbac.Cancel','Cancel',0,'opsportal',24,'2018-10-31 12:46:21',NULL),
	('en','rbac.user.selectSomeStuffEdit','Select one or more scopes for this Role assignment:',0,'opsportal',25,'2018-10-31 12:46:21',NULL),
	('en','rbac.Update','Update',0,'opsportal',26,'2018-10-31 12:46:21',NULL),
	('en','rbac.users.userID','User ID',0,'opsportal',27,'2018-10-31 12:46:21',NULL),
	('en','rbac.users.status','Status',0,'opsportal',28,'2018-10-31 12:46:21',NULL),
	('en','rbac.users.enabled','Enabled',0,'opsportal',29,'2018-10-31 12:46:21',NULL),
	('en','rbac.user.noUserSelected','no user selected',0,'opsportal',30,'2018-10-31 12:46:21',NULL),
	('en','rbac.roles.search','search for roles',0,'opsportal',31,'2018-10-31 12:46:21',NULL),
	('en','rbac.roles.name','Name',0,'opsportal',32,'2018-10-31 12:46:21',NULL),
	('en','rbac.roles.description','Description',0,'opsportal',33,'2018-10-31 12:46:21',NULL),
	('en','rbac.roles.confirmDelete','This will remove %s',0,'opsportal',34,'2018-10-31 12:46:21',NULL),
	('en','rbac.user.search','search for users',0,'opsportal',35,'2018-10-31 12:46:21',NULL),
	('en','rbac.roles.confirmClone','Clone role %s',0,'opsportal',36,'2018-10-31 12:46:21',NULL),
	('en','rbac.roles.searchActions','search for actions',0,'opsportal',37,'2018-10-31 12:46:21',NULL),
	('en','rbac.roles.newRole','Spiffy New Role',0,'opsportal',38,'2018-10-31 12:46:21',NULL),
	('en','rbac.roles.newRoleDescription','Describe this role',0,'opsportal',39,'2018-10-31 12:46:21',NULL),
	('en','opp.toolProcessReport','Create/Edit Reports',0,'opsportal',40,'2018-10-31 12:46:21',NULL),
	('en','opp.toolRunReport','Run Reports',0,'opsportal',41,'2018-10-31 12:46:21',NULL),
	('en','site.user.profile','User Profile',0,'opsportal',42,'2018-10-31 12:46:21',NULL),
	('en','site.user.switcheroo','Switcheroo',0,'opsportal',43,'2018-10-31 12:46:21',NULL),
	('en','site.user.logout','Logout',0,'opsportal',44,'2018-10-31 12:46:21',NULL),
	('en','site.user.info','Information',0,'opsportal',45,'2018-10-31 12:46:21',NULL),
	('en','site.user.username','Username',0,'opsportal',46,'2018-10-31 12:46:21',NULL),
	('en','site.user.password','Password',0,'opsportal',47,'2018-10-31 12:46:21',NULL),
	('en','site.user.newPassword','New Password',0,'opsportal',48,'2018-10-31 12:46:21',NULL),
	('en','site.user.confirmPassword','Confirm Password',0,'opsportal',49,'2018-10-31 12:46:21',NULL),
	('en','site.user.update','Update',0,'opsportal',50,'2018-10-31 12:46:21',NULL),
	('en','site.user.email','Email',0,'opsportal',51,'2018-10-31 12:46:21',NULL),
	('en','site.user.emailAddress','Email address',0,'opsportal',52,'2018-10-31 12:46:21',NULL),
	('en','site.user.language','Language',0,'opsportal',53,'2018-10-31 12:46:21',NULL),
	('en','site.user.chooseLanguage','Choose your default language for the web site:',0,'opsportal',54,'2018-10-31 12:46:21',NULL),
	('en','rbac.users.isActive','Is Active',0,'opsportal',55,'2018-10-31 12:46:21',NULL),
	('en','rbac.user.loadingPermissions','Loading Permissions for %s',0,'opsportal',56,'2018-10-31 12:46:21',NULL),
	('en','rbac.scopes.search','search for scopes',0,'opsportal',57,'2018-10-31 12:46:21',NULL),
	('en','rbac.scopes.add','add',0,'opsportal',58,'2018-10-31 12:46:21',NULL),
	('en','rbac.scopes.cancel','Cancel*',0,'opsportal',59,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.Add','Add',0,'opsportal',60,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.Save','Save',0,'opsportal',61,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.Edit','Edit',0,'opsportal',62,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.Delete','Delete',0,'opsportal',63,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.Cancel','Cancel',0,'opsportal',64,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.MenuItemProperties','Menu Area Properties',0,'opsportal',65,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.Label','Label',0,'opsportal',66,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.Icons','Icons',0,'opsportal',67,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.ex','ex',0,'opsportal',68,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.NewArea','New Area',0,'opsportal',69,'2018-10-31 12:46:21',NULL),
	('en','opp.reauth.required','Re-login required',0,'opsportal',70,'2018-10-31 12:46:21',NULL),
	('en','opp.reauth.submit','Submit',0,'opsportal',71,'2018-10-31 12:46:21',NULL),
	('en','opp.auth.E_INVALIDAUTH','Username and/or password not found',0,'opsportal',72,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.ToolProperties','Tool Properties',0,'opsportal',73,'2018-10-31 12:46:21',NULL),
	('en','opnavedit.isDefaultTool','is default tool?',0,'opsportal',74,'2018-10-31 12:46:21',NULL),
	('en','webix.common.list','List View',0,'opsportal',75,'2018-10-31 12:46:21',NULL),
	('en','webix.common.new','New',0,'opsportal',76,'2018-10-31 12:46:21',NULL),
	('en','webix.common.filter','Filter',0,'opsportal',77,'2018-10-31 12:46:21',NULL),
	('en','webix.common.cancel','Cancel',0,'opsportal',78,'2018-10-31 12:46:21',NULL),
	('en','webix.common.save','Save',0,'opsportal',79,'2018-10-31 12:46:21',NULL),
	('en','opp.dialog.confirm.deleteTitle','Confirm Delete',0,'opsportal',80,'2018-10-31 12:46:21',NULL),
	('en','opp.common.delete','Delete',0,'opsportal',81,'2018-10-31 12:46:21',NULL),
	('en','opp.common.cancel','Cancel',0,'opsportal',82,'2018-10-31 12:46:21',NULL),
	('en','opp.dialog.confirm.deleteMsg','Are you sure you want to delete <b>%s</b>?',0,'opsportal',83,'2018-10-31 12:46:21',NULL),
	('en','opp.perm.notPermitted','Not Permitted',0,'opsportal',84,'2018-10-31 12:46:21',NULL),
	('th','opp.configuringTools','สร้างเครื่องมือระบบบริการสารสนเทศ',0,'opsportal',85,'2018-10-31 12:46:21',NULL),
	('th','opp.menu','เมนู',0,'opsportal',86,'2018-10-31 12:46:21',NULL),
	('th','opp.error','ข้อผิดพลาด',0,'opsportal',87,'2018-10-31 12:46:21',NULL),
	('th','opp.enterPortal','การเข้าสู่ระบบบริการ',0,'opsportal',88,'2018-10-31 12:46:21',NULL),
	('th','opp.areaAdministration','ฝ่ายบริหาร',0,'opsportal',89,'2018-10-31 12:46:21',NULL),
	('th','opp.toolPermissions','อนุญาต',0,'opsportal',90,'2018-10-31 12:46:21',NULL),
	('th','opp.areaProfile','ข้อมูลโดยรวม',0,'opsportal',91,'2018-10-31 12:46:21',NULL),
	('th','opp.toolProfile','ข้อมูลโดยรวม',0,'opsportal',92,'2018-10-31 12:46:21',NULL),
	('th','opp.toolObjectBuilder','สร้างวัตถุ',0,'opsportal',93,'2018-10-31 12:46:21',NULL),
	('th','opp.areaProcess','เครื่องมือสำหรับขั้นตอน',0,'opsportal',94,'2018-10-31 12:46:21',NULL),
	('th','opp.toolProcessApproval','การอนุมัติ',0,'opsportal',95,'2018-10-31 12:46:21',NULL),
	('th','opp.toolProcessTranslation','สิ่งที่แปล',0,'opsportal',96,'2018-10-31 12:46:21',NULL),
	('th','opp.toolActivityReporting','หน้าควบคุมระบบ',0,'opsportal',97,'2018-10-31 12:46:21',NULL),
	('th','opp.areaFCFActivities','กิจกรรม',0,'opsportal',98,'2018-10-31 12:46:21',NULL),
	('th','opp.errorNoPermission','คุณไม่ได้รับการอนุญาต กรุณาสอบถามผู้บริหารของคุณเพื่อทำรายการ',0,'opsportal',99,'2018-10-31 12:46:21',NULL),
	('th','rbac.user.confirmRemoveRole','สิ่งนี้จะนำตำแหน่ง  %s ออก',0,'opsportal',100,'2018-10-31 12:46:21',NULL),
	('th','rbac.user.enabled','เปิดใช้งาน',0,'opsportal',101,'2018-10-31 12:46:21',NULL),
	('th','rbac.Users','ผู้ใช้',0,'opsportal',102,'2018-10-31 12:46:21',NULL),
	('th','rbac.user.add','เพิ่ม',0,'opsportal',103,'2018-10-31 12:46:21',NULL),
	('th','rbac.user.selectSomeStuff','เลือกหนึ่งตำแหน่งหนึ่งและหนึ่งขอบเขตหรือมากกว่าเพื่อการทำงานนี้',0,'opsportal',104,'2018-10-31 12:46:21',NULL),
	('th','rbac.Roles','ตำแหน่ง',0,'opsportal',105,'2018-10-31 12:46:21',NULL),
	('th','rbac.Scopes','ขอบเขต',0,'opsportal',106,'2018-10-31 12:46:21',NULL),
	('th','rbac.Add','เพิ่ม',0,'opsportal',107,'2018-10-31 12:46:21',NULL),
	('th','rbac.Cancel','ยกเลิก',0,'opsportal',108,'2018-10-31 12:46:21',NULL),
	('th','rbac.user.selectSomeStuffEdit','หนึ่งขอบเขตหรือมากกว่าเพื่อการทำงานนี้เพื่อตำแหน่งงานนี้',0,'opsportal',109,'2018-10-31 12:46:21',NULL),
	('th','rbac.Update','ทำให้เป็นปัจจุบัน',0,'opsportal',110,'2018-10-31 12:46:21',NULL),
	('th','rbac.users.userID','ชื่อผู้ใช้',0,'opsportal',111,'2018-10-31 12:46:21',NULL),
	('th','rbac.users.status','สถานะ',0,'opsportal',112,'2018-10-31 12:46:21',NULL),
	('th','rbac.users.enabled','ใช้การได้',0,'opsportal',113,'2018-10-31 12:46:21',NULL),
	('th','rbac.user.noUserSelected','ไม่ได้เลือกผู้ใช้',0,'opsportal',114,'2018-10-31 12:46:21',NULL),
	('th','rbac.roles.search','ค้นหาตำแหน่ง',0,'opsportal',115,'2018-10-31 12:46:21',NULL),
	('th','rbac.roles.name','ชื่อ',0,'opsportal',116,'2018-10-31 12:46:21',NULL),
	('th','rbac.roles.description','คำบรรยาย',0,'opsportal',117,'2018-10-31 12:46:21',NULL),
	('th','rbac.roles.confirmDelete','สิ่งนี้จะทำให้ %s ถูกกำจัดออกไป',0,'opsportal',118,'2018-10-31 12:46:21',NULL),
	('th','rbac.user.search','ค้นหาผู้ใช้',0,'opsportal',119,'2018-10-31 12:46:21',NULL),
	('th','rbac.roles.confirmClone','หาตำแหน่งงานที่เหมือนกัน %s',0,'opsportal',120,'2018-10-31 12:46:21',NULL),
	('th','rbac.roles.searchActions','ค้นหาการเคลื่อนไหว',0,'opsportal',121,'2018-10-31 12:46:21',NULL),
	('th','rbac.roles.newRole','ตำแห่นงใหม่ที่เก๋ไก๋',0,'opsportal',122,'2018-10-31 12:46:21',NULL),
	('th','rbac.roles.newRoleDescription','อธิบายถึงตำแหน่งนี้',0,'opsportal',123,'2018-10-31 12:46:21',NULL),
	('th','opp.toolProcessReport','เพิ่ม/แก้ไข รายงาน',0,'opsportal',124,'2018-10-31 12:46:21',NULL),
	('th','opp.toolRunReport','รายงาน',0,'opsportal',125,'2018-10-31 12:46:21',NULL),
	('th','site.user.profile','ประวัติผู้ใช้',0,'opsportal',126,'2018-10-31 12:46:21',NULL),
	('th','site.user.switcheroo','แลก',0,'opsportal',127,'2018-10-31 12:46:21',NULL),
	('th','site.user.logout','ลงชื่อออก',0,'opsportal',128,'2018-10-31 12:46:21',NULL),
	('th','site.user.info','[th]Information',0,'opsportal',129,'2018-10-31 12:46:21',NULL),
	('th','site.user.username','[th]Username',0,'opsportal',130,'2018-10-31 12:46:21',NULL),
	('th','site.user.password','[th]Password',0,'opsportal',131,'2018-10-31 12:46:21',NULL),
	('th','site.user.newPassword','[th]New Password',0,'opsportal',132,'2018-10-31 12:46:21',NULL),
	('th','site.user.confirmPassword','[th]Confirm Password',0,'opsportal',133,'2018-10-31 12:46:21',NULL),
	('th','site.user.update','[th]Update',0,'opsportal',134,'2018-10-31 12:46:21',NULL),
	('th','site.user.email','[th]Email',0,'opsportal',135,'2018-10-31 12:46:21',NULL),
	('th','site.user.emailAddress','[th]Email address',0,'opsportal',136,'2018-10-31 12:46:21',NULL),
	('th','site.user.language','[th]Language',0,'opsportal',137,'2018-10-31 12:46:21',NULL),
	('th','site.user.chooseLanguage','[th]Choose your default language for the web site:',0,'opsportal',138,'2018-10-31 12:46:21',NULL),
	('th','rbac.users.isActive','[th]Is Active',0,'opsportal',139,'2018-10-31 12:46:21',NULL),
	('th','rbac.user.loadingPermissions','[th]Loading Permissions for %s',0,'opsportal',140,'2018-10-31 12:46:21',NULL),
	('th','rbac.scopes.search','[th]search for scopes',0,'opsportal',141,'2018-10-31 12:46:21',NULL),
	('th','rbac.scopes.add','[th]add',0,'opsportal',142,'2018-10-31 12:46:21',NULL),
	('th','rbac.scopes.cancel','[th]Cancel*',0,'opsportal',143,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.Add','[th]Add',0,'opsportal',144,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.Save','[th]Save',0,'opsportal',145,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.Edit','[th]Edit',0,'opsportal',146,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.Delete','[th]Delete',0,'opsportal',147,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.Cancel','[th]Cancel',0,'opsportal',148,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.MenuItemProperties','[th]Menu Area Properties',0,'opsportal',149,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.Label','[th]Label',0,'opsportal',150,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.Icons','[th]Icons',0,'opsportal',151,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.ex','[th]ex',0,'opsportal',152,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.NewArea','[th]New Area',0,'opsportal',153,'2018-10-31 12:46:21',NULL),
	('th','opp.reauth.required','[th]Re-login required',0,'opsportal',154,'2018-10-31 12:46:21',NULL),
	('th','opp.reauth.submit','[th]Submit',0,'opsportal',155,'2018-10-31 12:46:21',NULL),
	('th','opp.auth.E_INVALIDAUTH','[th]Username and/or password not found',0,'opsportal',156,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.ToolProperties','[th]Tool Properties',0,'opsportal',157,'2018-10-31 12:46:21',NULL),
	('th','opnavedit.isDefaultTool','[th]is default tool?',0,'opsportal',158,'2018-10-31 12:46:21',NULL),
	('th','webix.common.list','[th] List View',0,'opsportal',159,'2018-10-31 12:46:21',NULL),
	('th','webix.common.new','[th] New',0,'opsportal',160,'2018-10-31 12:46:21',NULL),
	('th','webix.common.filter','[th] Filter',0,'opsportal',161,'2018-10-31 12:46:21',NULL),
	('th','webix.common.cancel','[th] Cancel',0,'opsportal',162,'2018-10-31 12:46:21',NULL),
	('th','webix.common.save','[th] Save',0,'opsportal',163,'2018-10-31 12:46:21',NULL),
	('th','opp.dialog.confirm.deleteTitle','[th] Confirm Delete',0,'opsportal',164,'2018-10-31 12:46:21',NULL),
	('th','opp.common.delete','[th] Delete',0,'opsportal',165,'2018-10-31 12:46:21',NULL),
	('th','opp.common.cancel','[th] Cancel',0,'opsportal',166,'2018-10-31 12:46:21',NULL),
	('th','opp.dialog.confirm.deleteMsg','[th] Are you sure you want to delete <b>%s</b>?',0,'opsportal',167,'2018-10-31 12:46:21',NULL),
	('th','opp.perm.notPermitted','[th] Not Permitted',0,'opsportal',168,'2018-10-31 12:46:21',NULL),
	('en','ab.common.edit','Edit',0,'app_builder',169,'2018-10-31 12:46:22',NULL),
	('en','ab.common.save','Save',0,'app_builder',170,'2018-10-31 12:46:22',NULL),
	('en','ab.common.delete','Delete',0,'app_builder',171,'2018-10-31 12:46:22',NULL),
	('en','ab.common.cancel','Cancel',0,'app_builder',172,'2018-10-31 12:46:22',NULL),
	('en','ab.common.yes','Yes',0,'app_builder',173,'2018-10-31 12:46:22',NULL),
	('en','ab.common.no','No',0,'app_builder',174,'2018-10-31 12:46:22',NULL),
	('en','ab.common.ok','Ok',0,'app_builder',175,'2018-10-31 12:46:22',NULL),
	('en','ab.common.add','Add',0,'app_builder',176,'2018-10-31 12:46:22',NULL),
	('en','ab.common.search','Search',0,'app_builder',177,'2018-10-31 12:46:22',NULL),
	('en','ab.common.close','Close',0,'app_builder',178,'2018-10-31 12:46:22',NULL),
	('en','ab.common.newName','New Name',0,'app_builder',179,'2018-10-31 12:46:22',NULL),
	('en','ab.common.rename','Rename',0,'app_builder',180,'2018-10-31 12:46:22',NULL),
	('en','ab.common.processing','Processing...',0,'app_builder',181,'2018-10-31 12:46:22',NULL),
	('en','ab.common.form.name','Name',0,'app_builder',182,'2018-10-31 12:46:22',NULL),
	('en','ab.common.form.description','Description',0,'app_builder',183,'2018-10-31 12:46:22',NULL),
	('en','ab.common.headerName','Header name',0,'app_builder',184,'2018-10-31 12:46:22',NULL),
	('en','ab.common.create.error','System could not create <b>{0}</b>.',0,'app_builder',185,'2018-10-31 12:46:22',NULL),
	('en','ab.common.create.success','<b>{0}</b> is created.',0,'app_builder',186,'2018-10-31 12:46:22',NULL),
	('en','ab.common.update.error','System could not update <b>{0}</b>.',0,'app_builder',187,'2018-10-31 12:46:22',NULL),
	('en','ab.common.update.success','<b>{0}</b> is updated.',0,'app_builder',188,'2018-10-31 12:46:22',NULL),
	('en','ab.common.rename.error','System could not rename <b>{0}</b>.',0,'app_builder',189,'2018-10-31 12:46:22',NULL),
	('en','ab.common.rename.success','Rename to <b>{0}</b>.',0,'app_builder',190,'2018-10-31 12:46:22',NULL),
	('en','ab.common.delete.error','System could not delete <b>{0}</b>.',0,'app_builder',191,'2018-10-31 12:46:22',NULL),
	('en','ab.common.delete.success','<b>{0}</b> is deleted.',0,'app_builder',192,'2018-10-31 12:46:22',NULL),
	('en','ab.application.application','Application',0,'app_builder',193,'2018-10-31 12:46:22',NULL),
	('en','ab.application.createNew','Add new application',0,'app_builder',194,'2018-10-31 12:46:22',NULL),
	('en','ab.application.menu','Application Menu',0,'app_builder',195,'2018-10-31 12:46:22',NULL),
	('en','ab.application.unsyncDataMessage','There are {0} out of sync data',0,'app_builder',196,'2018-10-31 12:46:22',NULL),
	('en','ab.application.unsyncDataHeader','Unsynchronized data',0,'app_builder',197,'2018-10-31 12:46:22',NULL),
	('en','ab.application.synchronize','Synchronize',0,'app_builder',198,'2018-10-31 12:46:22',NULL),
	('en','ab.application.dataOfflineMessage','This data is offline.',0,'app_builder',199,'2018-10-31 12:46:22',NULL),
	('en','ab.application.backToApplication','Back to Applications page',0,'app_builder',200,'2018-10-31 12:46:22',NULL),
	('en','ab.application.delete.title','Delete application',0,'app_builder',201,'2018-10-31 12:46:22',NULL),
	('en','ab.application.delete.message','Do you want to delete <b>{0}</b>?',0,'app_builder',202,'2018-10-31 12:46:22',NULL),
	('en','ab.application.form.header','Application Info',0,'app_builder',203,'2018-10-31 12:46:22',NULL),
	('en','ab.application.form.placeholderName','Application name',0,'app_builder',204,'2018-10-31 12:46:22',NULL),
	('en','ab.application.form.placeholderDescription','Application description',0,'app_builder',205,'2018-10-31 12:46:22',NULL),
	('en','ab.object.title','Objects',0,'app_builder',206,'2018-10-31 12:46:22',NULL),
	('en','ab.object.invalidName','This name is invalid',0,'app_builder',207,'2018-10-31 12:46:22',NULL),
	('en','ab.object.duplicateName','<b>{0}</b> is duplicate',0,'app_builder',208,'2018-10-31 12:46:22',NULL),
	('en','ab.object.addNew','Add new object',0,'app_builder',209,'2018-10-31 12:46:22',NULL),
	('en','ab.object.menu','Object Menu',0,'app_builder',210,'2018-10-31 12:46:22',NULL),
	('en','ab.object.form.placeholderName','Object name',0,'app_builder',211,'2018-10-31 12:46:22',NULL),
	('en','ab.object.hideField','Hide field',0,'app_builder',212,'2018-10-31 12:46:22',NULL),
	('en','ab.object.filterField','Filter field',0,'app_builder',213,'2018-10-31 12:46:22',NULL),
	('en','ab.object.sortField','Sort field',0,'app_builder',214,'2018-10-31 12:46:22',NULL),
	('en','ab.object.editField','Edit field',0,'app_builder',215,'2018-10-31 12:46:22',NULL),
	('en','ab.object.deleteField','Delete field',0,'app_builder',216,'2018-10-31 12:46:22',NULL),
	('en','ab.object.addNewRow','Add new row',0,'app_builder',217,'2018-10-31 12:46:22',NULL),
	('en','ab.object.couldNotDeleteField','Could not delete',0,'app_builder',218,'2018-10-31 12:46:22',NULL),
	('en','ab.object.atLeastOneField','Object should have at least one field.',0,'app_builder',219,'2018-10-31 12:46:22',NULL),
	('en','ab.object.couldNotReorderField','Could not reorder columns',0,'app_builder',220,'2018-10-31 12:46:22',NULL),
	('en','ab.object.couldNotReorderFieldDetail','There are hidden columns.',0,'app_builder',221,'2018-10-31 12:46:22',NULL),
	('en','ab.object.selectConnectedData','Select data to connect',0,'app_builder',222,'2018-10-31 12:46:22',NULL),
	('en','ab.object.cannotConnectedDataTitle','System could not link to this data',0,'app_builder',223,'2018-10-31 12:46:22',NULL),
	('en','ab.object.cannotConnectedDataDescription','This data is unsynchronized. You can click Synchronize button to sync data.',0,'app_builder',224,'2018-10-31 12:46:22',NULL),
	('en','ab.object.noConnectedData','',0,'app_builder',225,'2018-10-31 12:46:22',NULL),
	('en','ab.object.connectToObjectName','(Connect to <b>{0}</b>)',0,'app_builder',226,'2018-10-31 12:46:22',NULL),
	('en','ab.object.delete.title','Delete data field',0,'app_builder',227,'2018-10-31 12:46:22',NULL),
	('en','ab.object.delete.message','Do you want to delete <b>{0}</b>?',0,'app_builder',228,'2018-10-31 12:46:22',NULL),
	('en','ab.object.deleteRow.title','Delete data',0,'app_builder',229,'2018-10-31 12:46:22',NULL),
	('en','ab.object.deleteRow.message','Do you want to delete this row?',0,'app_builder',230,'2018-10-31 12:46:22',NULL),
	('en','ab.object.toolbar.hideFields','Hide fields',0,'app_builder',231,'2018-10-31 12:46:22',NULL),
	('en','ab.object.toolbar.filterFields','Add filters',0,'app_builder',232,'2018-10-31 12:46:22',NULL),
	('en','ab.object.toolbar.sortFields','Apply sort',0,'app_builder',233,'2018-10-31 12:46:22',NULL),
	('en','ab.object.toolbar.frozenColumns','Frozen columns',0,'app_builder',234,'2018-10-31 12:46:22',NULL),
	('en','ab.object.toolbar.defineLabel','Define label',0,'app_builder',235,'2018-10-31 12:46:22',NULL),
	('en','ab.object.toolbar.permission','Permission',0,'app_builder',236,'2018-10-31 12:46:22',NULL),
	('en','ab.object.toolbar.addFields','Add new column',0,'app_builder',237,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.chooseType','Choose field type...',0,'app_builder',238,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.fieldName','Field name',0,'app_builder',239,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.label','Label',0,'app_builder',240,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.connectField','Connect to another record',0,'app_builder',241,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.stringField','Single line text',0,'app_builder',242,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.textField','Long text',0,'app_builder',243,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.numberField','Number',0,'app_builder',244,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.dateField','Date',0,'app_builder',245,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.booleanField','Checkbox',0,'app_builder',246,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.listField','Select list',0,'app_builder',247,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.attachmentField','Attachment',0,'app_builder',248,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.defaultText','Default text',0,'app_builder',249,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.defaultNumber','Default number',0,'app_builder',250,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.supportMultilingual','Support multilingual',0,'app_builder',251,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.connectToObject','Connect to Object',0,'app_builder',252,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.connectToNewObject','Connect to new Object',0,'app_builder',253,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.allowConnectMultipleValue','Allow connecting to multiple records',0,'app_builder',254,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.requireConnectedObjectTitle','Object required',0,'app_builder',255,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.requireConnectedObjectDescription','Please select object to connect.',0,'app_builder',256,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.textDescription','A long text field that can span multiple lines.',0,'app_builder',257,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.format','Format',0,'app_builder',258,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.numberFormat','Number',0,'app_builder',259,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.priceFormat','Price',0,'app_builder',260,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.allowDecimalNumbers','Allow decimal numbers',0,'app_builder',261,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.pickDate','Pick one from a calendar.',0,'app_builder',262,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.includeTime','Include time',0,'app_builder',263,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.booleanDescription','A single checkbox that can be checked or unchecked.',0,'app_builder',264,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.listDescription','Single select allows you to select a single predefined options below from a dropdown.',0,'app_builder',265,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.listOption','Options',0,'app_builder',266,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.listAddNewOption','Add new option',0,'app_builder',267,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.requireListOptionTitle','Option required',0,'app_builder',268,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.requireListOptionDescription','Enter at least one option.',0,'app_builder',269,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.addNewField','Add Column',0,'app_builder',270,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.registerTableWarning','Please register the datatable to add.',0,'app_builder',271,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.invalidFieldTitle','Your field name is invalid format',0,'app_builder',272,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.invalidFieldDescription','System disallow enter special character to field name.',0,'app_builder',273,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.duplicateFieldTitle','Your field name is duplicate',0,'app_builder',274,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.duplicateFieldDescription','Please change your field name',0,'app_builder',275,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.cannotUpdateFields','Could not update columns',0,'app_builder',276,'2018-10-31 12:46:22',NULL),
	('en','ab.add_fields.waitRestructureObjects','Please wait until restructure objects is complete',0,'app_builder',277,'2018-10-31 12:46:22',NULL),
	('en','ab.define_label.labelFormat','Label format',0,'app_builder',278,'2018-10-31 12:46:22',NULL),
	('en','ab.define_label.selectFieldToGenerate','Select field item to generate format.',0,'app_builder',279,'2018-10-31 12:46:22',NULL),
	('en','ab.define_label.labelFields','Fields',0,'app_builder',280,'2018-10-31 12:46:22',NULL),
	('en','ab.define_label.loadError','System could not load label format data',0,'app_builder',281,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.and','And',0,'app_builder',282,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.or','Or',0,'app_builder',283,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.addNewFilter','Add a filter',0,'app_builder',284,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.containsCondition','contains',0,'app_builder',285,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.notContainCondition','doesn\'t contain',0,'app_builder',286,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.isCondition','is',0,'app_builder',287,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.isNotCondition','is not',0,'app_builder',288,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.beforeCondition','is before',0,'app_builder',289,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.afterCondition','is after',0,'app_builder',290,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.onOrBeforeCondition','is on or before',0,'app_builder',291,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.onOrAfterCondition','is on or after',0,'app_builder',292,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.equalCondition','=',0,'app_builder',293,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.notEqualCondition','≠',0,'app_builder',294,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.lessThanCondition','<',0,'app_builder',295,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.moreThanCondition','>',0,'app_builder',296,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.lessThanOrEqualCondition','≤',0,'app_builder',297,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.moreThanOrEqualCondition','≥',0,'app_builder',298,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.equalListCondition','equals',0,'app_builder',299,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.notEqualListCondition','does not equal',0,'app_builder',300,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.checkedCondition','is checked',0,'app_builder',301,'2018-10-31 12:46:22',NULL),
	('en','ab.filter_fields.notCheckedCondition','is not checked',0,'app_builder',302,'2018-10-31 12:46:22',NULL),
	('en','ab.frozen_fields.clearAll','Clear all',0,'app_builder',303,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.addNewSort','Add new sort',0,'app_builder',304,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.selectField','Please select field',0,'app_builder',305,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.textAsc','A -> Z',0,'app_builder',306,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.textDesc','Z -> A',0,'app_builder',307,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.dateAsc','Before -> After',0,'app_builder',308,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.dateDesc','After -> Before',0,'app_builder',309,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.numberAsc','1 -> 9',0,'app_builder',310,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.numberDesc','9 -> 1',0,'app_builder',311,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.booleanAsc','Checked -> Unchecked',0,'app_builder',312,'2018-10-31 12:46:22',NULL),
	('en','ab.sort_fields.booleanDesc','Unchecked -> Checked',0,'app_builder',313,'2018-10-31 12:46:22',NULL),
	('en','ab.visible_fields.showAll','Show all',0,'app_builder',314,'2018-10-31 12:46:22',NULL),
	('en','ab.visible_fields.hideAll','Hide all',0,'app_builder',315,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.page','Interface',0,'app_builder',316,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.addNewPage','Add a new page',0,'app_builder',317,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.placeholderPageName','Page Name',0,'app_builder',318,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.delete.title','Delete page',0,'app_builder',319,'2018-10-31 12:46:22',NULL),
	('en','ab.common.import','Import',0,'app_builder',320,'2018-10-31 12:46:22',NULL),
	('en','ab.common.export','Export',0,'app_builder',321,'2018-10-31 12:46:22',NULL),
	('en','ab.common.save.error','System could not save <b>{0}</b>.',0,'app_builder',322,'2018-10-31 12:46:22',NULL),
	('en','ab.common.save.success','<b>{0}</b> is saved.',0,'app_builder',323,'2018-10-31 12:46:22',NULL),
	('en','ab.equation.date_year','%s:Returns the year of a given date',0,'app_builder',324,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.delete.message','Do you want to delete <b>{0}</b>?',0,'app_builder',325,'2018-10-31 12:46:22',NULL),
	('en','ab.component.tab.addPage','Add a tab below',0,'app_builder',326,'2018-10-31 12:46:22',NULL),
	('en','ab.component.tab.enterTabName','Enter a tab name',0,'app_builder',327,'2018-10-31 12:46:22',NULL),
	('en','ab.component.tab.invalidTabName','Tab name cannot be empty',0,'app_builder',328,'2018-10-31 12:46:22',NULL),
	('en','ab.component.tab.chooseIcon','Choose an icon',0,'app_builder',329,'2018-10-31 12:46:22',NULL),
	('en','ab.component.tab.addTab','Add Tab',0,'app_builder',330,'2018-10-31 12:46:22',NULL),
	('en','ab.validate.overMaxLength','This input value is invalid',0,'app_builder',331,'2018-10-31 12:46:22',NULL),
	('en','ab.validate.overMaxLengthDescription','Should not have number of character more than #maxLength#.',0,'app_builder',332,'2018-10-31 12:46:22',NULL),
	('en','ab.validate.invalidFormat','This input value is invalid format',0,'app_builder',333,'2018-10-31 12:46:22',NULL),
	('en','ab.validate.invalidFormatDescription','System disallow enter special character.',0,'app_builder',334,'2018-10-31 12:46:22',NULL),
	('en','ab.application.invalidName','This application name is invalid',0,'app_builder',335,'2018-10-31 12:46:22',NULL),
	('en','ab.application.duplicateName','#appName# is duplicate.',0,'app_builder',336,'2018-10-31 12:46:22',NULL),
	('en','ab.components.label','Label',0,'app_builder',337,'2018-10-31 12:46:22',NULL),
	('en','ab.component.label.text','Text',0,'app_builder',338,'2018-10-31 12:46:22',NULL),
	('en','ab.component.label.textPlaceholder','Text Placeholder',0,'app_builder',339,'2018-10-31 12:46:22',NULL),
	('en','ab.component.label.formatting','format options:',0,'app_builder',340,'2018-10-31 12:46:22',NULL),
	('en','ab.component.label.formatting.normal','normal',0,'app_builder',341,'2018-10-31 12:46:22',NULL),
	('en','ab.component.label.formatting.title','title',0,'app_builder',342,'2018-10-31 12:46:22',NULL),
	('en','ab.component.label.formatting.description','description',0,'app_builder',343,'2018-10-31 12:46:22',NULL),
	('en','ab.components.view','View',0,'app_builder',344,'2018-10-31 12:46:22',NULL),
	('en','ab.validation.view.label.unique','View label must be unique among peers.',0,'app_builder',345,'2018-10-31 12:46:22',NULL),
	('en','ab.components.view.dropHere','Drop Component Here',0,'app_builder',346,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.component.confirmDeleteTitle','Delete Component',0,'app_builder',347,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.component.confirmDeleteMessage','Do you want to delete <b>{0}</b>?',0,'app_builder',348,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.properties','Properties',0,'app_builder',349,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.selectPage','Select a Page to edit',0,'app_builder',350,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.viewModeBlock','Block',0,'app_builder',351,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.viewModePreview','Preview',0,'app_builder',352,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.page.parentList','Parent Page',0,'app_builder',353,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.rootPage','[Root Page]',0,'app_builder',354,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.components','Components',0,'app_builder',355,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.noComponents','No Components',0,'app_builder',356,'2018-10-31 12:46:22',NULL),
	('en','ab.dataField.common.headerLabel','Section Title',0,'app_builder',357,'2018-10-31 12:46:22',NULL),
	('en','ab.dataField.common.headerLabelPlaceholder','Section Name',0,'app_builder',358,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.quickPage','Quick Page',0,'app_builder',359,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.blankPage','Blank Page',0,'app_builder',360,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.title','Interface',0,'app_builder',361,'2018-10-31 12:46:22',NULL),
	('en','ab.object.selectObject','Select an object to work with.',0,'app_builder',362,'2018-10-31 12:46:22',NULL),
	('en','ab.common.none','None',0,'app_builder',363,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.dataSource','Data Source',0,'app_builder',364,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.object','Object',0,'app_builder',365,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.linkedTo','Linked To',0,'app_builder',366,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.linkField','Link Field',0,'app_builder',367,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.text','Text',0,'app_builder',368,'2018-10-31 12:46:22',NULL),
	('en','ab.abfield.labelPlaceholder','label placeholder',0,'app_builder',369,'2018-10-31 12:46:22',NULL),
	('en','ab.component.form.text.useFormDefaults','use form defaults',0,'app_builder',370,'2018-10-31 12:46:22',NULL),
	('en','ab.components.button','Button',0,'app_builder',371,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form','Form',0,'app_builder',372,'2018-10-31 12:46:22',NULL),
	('en','ab.components.checkbox','Checkbox',0,'app_builder',373,'2018-10-31 12:46:22',NULL),
	('en','ab.components.custom','Custom',0,'app_builder',374,'2018-10-31 12:46:22',NULL),
	('en','ab.components.detail','Detail',0,'app_builder',375,'2018-10-31 12:46:22',NULL),
	('en','ab.components.dataview','Data view',0,'app_builder',376,'2018-10-31 12:46:22',NULL),
	('en','ab.components.datepicker','Date Picker',0,'app_builder',377,'2018-10-31 12:46:22',NULL),
	('en','ab.components.grid','Grid',0,'app_builder',378,'2018-10-31 12:46:22',NULL),
	('en','ab.components.image','Image',0,'app_builder',379,'2018-10-31 12:46:22',NULL),
	('en','ab.components.layout','Layout',0,'app_builder',380,'2018-10-31 12:46:22',NULL),
	('en','ab.components.list','List',0,'app_builder',381,'2018-10-31 12:46:22',NULL),
	('en','ab.components.menu','Menu',0,'app_builder',382,'2018-10-31 12:46:22',NULL),
	('en','ab.components.number','Number',0,'app_builder',383,'2018-10-31 12:46:22',NULL),
	('en','ab.components.selectsingle','Single Select',0,'app_builder',384,'2018-10-31 12:46:22',NULL),
	('en','ab.components.tab','Tab',0,'app_builder',385,'2018-10-31 12:46:22',NULL),
	('en','ab.components.text','Text',0,'app_builder',386,'2018-10-31 12:46:22',NULL),
	('en','ab.components.textbox','Textbox',0,'app_builder',387,'2018-10-31 12:46:22',NULL),
	('en','ab.components.tree','Tree',0,'app_builder',388,'2018-10-31 12:46:22',NULL),
	('en','ab.components.pivot','Pivot',0,'app_builder',389,'2018-10-31 12:46:22',NULL),
	('en','ab.object.list.setting','Settings',0,'app_builder',390,'2018-10-31 12:46:22',NULL),
	('en','ab.object.list.search','Search',0,'app_builder',391,'2018-10-31 12:46:22',NULL),
	('en','ab.object.list.sort','Sort',0,'app_builder',392,'2018-10-31 12:46:22',NULL),
	('en','ab.object.list.sort.asc','A -> Z',0,'app_builder',393,'2018-10-31 12:46:22',NULL),
	('en','ab.object.list.sort.desc','Z -> A',0,'app_builder',394,'2018-10-31 12:46:22',NULL),
	('en','ab.object.list.group','Group',0,'app_builder',395,'2018-10-31 12:46:22',NULL),
	('en','ab.components.connect','Connect',0,'app_builder',396,'2018-10-31 12:46:22',NULL),
	('en','ab.components.chart','Chart',0,'app_builder',397,'2018-10-31 12:46:22',NULL),
	('en','ab.components.chart.pie','Pie Chart',0,'app_builder',398,'2018-10-31 12:46:22',NULL),
	('en','ab.components.chart.bar','Bar Chart',0,'app_builder',399,'2018-10-31 12:46:22',NULL),
	('en','ab.components.chart.line','Line Chart',0,'app_builder',400,'2018-10-31 12:46:22',NULL),
	('en','ab.components.chart.area','Area Chart',0,'app_builder',401,'2018-10-31 12:46:22',NULL),
	('en','ab.component.ruleaction.updateRecord','Update Record',0,'app_builder',402,'2018-10-31 12:46:22',NULL),
	('en','ab.component.ruleaction.insertConnectedObject','Insert Connected Object',0,'app_builder',403,'2018-10-31 12:46:22',NULL),
	('en','ab.component.ruleaction.updateConnectedRecord','Update Connected Record',0,'app_builder',404,'2018-10-31 12:46:22',NULL),
	('en','ab.ruleAction.Update.required','A value is required',0,'app_builder',405,'2018-10-31 12:46:22',NULL),
	('en','ab.component.form.set','Set',0,'app_builder',406,'2018-10-31 12:46:22',NULL),
	('en','ab.component.form.to','To',0,'app_builder',407,'2018-10-31 12:46:22',NULL),
	('en','ab.ruleAction.UpdateConnected.selectField','Select which connected object to update.',0,'app_builder',408,'2018-10-31 12:46:22',NULL),
	('en','ab.ruleAction.UpdateConnected.remoteCondition','How to choose which object:',0,'app_builder',409,'2018-10-31 12:46:22',NULL),
	('en','ab.component.form.action','Action',0,'app_builder',410,'2018-10-31 12:46:22',NULL),
	('en','ab.component.form.when','When',0,'app_builder',411,'2018-10-31 12:46:22',NULL),
	('en','ab.component.form.values','Values',0,'app_builder',412,'2018-10-31 12:46:22',NULL),
	('en','ab.interface.addWidget','Add Widget',0,'app_builder',413,'2018-10-31 12:46:22',NULL),
	('en','ab.common.componentDropZone','add widgets here',0,'app_builder',414,'2018-10-31 12:46:22',NULL),
	('en','ab.dataField.common.showIcon','show icon?',0,'app_builder',415,'2018-10-31 12:46:22',NULL),
	('en','ab.dataField.common.columnNamePlaceholder','Database field name',0,'app_builder',416,'2018-10-31 12:46:22',NULL),
	('en','ab.dataField.common.columnName','Field Name',0,'app_builder',417,'2018-10-31 12:46:22',NULL),
	('en','ab.dataField.common.fieldLabelPlaceholder','Label',0,'app_builder',418,'2018-10-31 12:46:22',NULL),
	('en','ab.dataField.common.fieldLabel','Label',0,'app_builder',419,'2018-10-31 12:46:22',NULL),
	('en','ab.components.conditionalcontainer','Conditional Container',0,'app_builder',420,'2018-10-31 12:46:22',NULL),
	('en','ab.components.container.columns','Columns',0,'app_builder',421,'2018-10-31 12:46:22',NULL),
	('en','ab.components.page.type','Type',0,'app_builder',422,'2018-10-31 12:46:22',NULL),
	('en','ab.component.selectsingle.type','Type',0,'app_builder',423,'2018-10-31 12:46:22',NULL),
	('en','ab.component.textbox.type','Type',0,'app_builder',424,'2018-10-31 12:46:22',NULL),
	('en','ab.dataField.file.fileType','Type',0,'app_builder',425,'2018-10-31 12:46:22',NULL),
	('en','ab.components.page.popup','Popup',0,'app_builder',426,'2018-10-31 12:46:22',NULL),
	('en','ab.components.page.page','Page',0,'app_builder',427,'2018-10-31 12:46:22',NULL),
	('en','ab.components.common.showlabel','Display Label',0,'app_builder',428,'2018-10-31 12:46:22',NULL),
	('en','ab.components.common.labelPosition','Label Position',0,'app_builder',429,'2018-10-31 12:46:22',NULL),
	('en','ab.components.common.left','Left',0,'app_builder',430,'2018-10-31 12:46:22',NULL),
	('en','ab.components.common.top','Top',0,'app_builder',431,'2018-10-31 12:46:22',NULL),
	('en','ab.components.common.labelWidth','Label Width',0,'app_builder',432,'2018-10-31 12:46:22',NULL),
	('en','ab.components.common.heigth','Height',0,'app_builder',433,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.clearOnLoad','Clear on load',0,'app_builder',434,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.rules','Rules',0,'app_builder',435,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.submitRules','Submit Rules',0,'app_builder',436,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.settings','Settings',0,'app_builder',437,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.displayRules','Display Rules',0,'app_builder',438,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.recordRules','Record Rules',0,'app_builder',439,'2018-10-31 12:46:22',NULL),
	('en','ab.components.common.height','Height',0,'app_builder',440,'2018-10-31 12:46:22',NULL),
	('en','ab.components.form.addNewRule','Add new rule',0,'app_builder',441,'2018-10-31 12:46:22',NULL),
	('th','ab.common.edit','แก้ไข',0,'app_builder',442,'2018-10-31 12:46:22',NULL),
	('th','ab.common.save','บันทึก',0,'app_builder',443,'2018-10-31 12:46:22',NULL),
	('th','ab.common.delete','ลบ',0,'app_builder',444,'2018-10-31 12:46:22',NULL),
	('th','ab.common.cancel','ยกเลิก',0,'app_builder',445,'2018-10-31 12:46:22',NULL),
	('th','ab.common.yes','ใช่',0,'app_builder',446,'2018-10-31 12:46:22',NULL),
	('th','ab.common.no','ไม่',0,'app_builder',447,'2018-10-31 12:46:22',NULL),
	('th','ab.common.ok','ตกลง',0,'app_builder',448,'2018-10-31 12:46:22',NULL),
	('th','ab.common.add','เพิ่ม',0,'app_builder',449,'2018-10-31 12:46:22',NULL),
	('th','ab.common.search','ค้นหา',0,'app_builder',450,'2018-10-31 12:46:22',NULL),
	('th','ab.common.close','ปิด',0,'app_builder',451,'2018-10-31 12:46:22',NULL),
	('th','ab.common.newName','ชื่อใหม่',0,'app_builder',452,'2018-10-31 12:46:22',NULL),
	('th','ab.common.rename','เปลี่ยนชื่อ',0,'app_builder',453,'2018-10-31 12:46:22',NULL),
	('th','ab.common.processing','กำลังประมวลผล...',0,'app_builder',454,'2018-10-31 12:46:22',NULL),
	('th','ab.common.form.name','ชื่อ',0,'app_builder',455,'2018-10-31 12:46:22',NULL),
	('th','ab.common.form.description','อธิบาย',0,'app_builder',456,'2018-10-31 12:46:22',NULL),
	('th','ab.common.headerName','ชื่อหัวตาราง',0,'app_builder',457,'2018-10-31 12:46:22',NULL),
	('th','ab.common.create.error','ระบบไม่สามารถสร้าง <b>{0}</b>',0,'app_builder',458,'2018-10-31 12:46:22',NULL),
	('th','ab.common.create.success','<b>{0}</b> ถูกสร้างแล้ว',0,'app_builder',459,'2018-10-31 12:46:22',NULL),
	('th','ab.common.update.error','ระบบไม่สมารถแก้ไข <b>{0}</b>',0,'app_builder',460,'2018-10-31 12:46:22',NULL),
	('th','ab.common.update.success','<b>{0}</b> ถูกแก้ไขแล้ว',0,'app_builder',461,'2018-10-31 12:46:22',NULL),
	('th','ab.common.rename.error','ระบบไม่สามารถเปลี่ยนชื่อ <b>{0}</b>',0,'app_builder',462,'2018-10-31 12:46:22',NULL),
	('th','ab.common.rename.success','เปลี่ยนชื่อเป็น <b>{0}</b>.',0,'app_builder',463,'2018-10-31 12:46:22',NULL),
	('th','ab.common.delete.error','ระบบไม่สามารถลบ <b>{0}</b>',0,'app_builder',464,'2018-10-31 12:46:22',NULL),
	('th','ab.common.delete.success','<b>{0}</b> ถูกลบแล้ว',0,'app_builder',465,'2018-10-31 12:46:22',NULL),
	('th','ab.application.application','แอปพลิเคชั่น',0,'app_builder',466,'2018-10-31 12:46:22',NULL),
	('th','ab.application.createNew','เพิ่มแอปพลิเคชั่นใหม่',0,'app_builder',467,'2018-10-31 12:46:22',NULL),
	('th','ab.application.menu','แอปพลิเคชั่น',0,'app_builder',468,'2018-10-31 12:46:22',NULL),
	('th','ab.application.unsyncDataMessage','มีข้อมูลที่ยังไม่ได้ซิ้งค์ เป็นจำนวน {0}',0,'app_builder',469,'2018-10-31 12:46:22',NULL),
	('th','ab.application.unsyncDataHeader','ข้อมูลที่ยังไม่ได้ซิ้งค์',0,'app_builder',470,'2018-10-31 12:46:22',NULL),
	('th','ab.application.synchronize','ซิ้งค์ข้อมูล',0,'app_builder',471,'2018-10-31 12:46:22',NULL),
	('th','ab.application.dataOfflineMessage','ข้อมูลชุดนี้ยังไม่ได้ถูกซิ้งค์ไปยังเซอร์เวอร์',0,'app_builder',472,'2018-10-31 12:46:22',NULL),
	('th','ab.application.backToApplication','กลับไปหน้าแอปพลิเคชั่น',0,'app_builder',473,'2018-10-31 12:46:22',NULL),
	('th','ab.application.delete.title','ลบแอปพลิเคชั่น',0,'app_builder',474,'2018-10-31 12:46:22',NULL),
	('th','ab.application.delete.message','คุณต้องการลบ <b>{0}</b> หรือไม่?',0,'app_builder',475,'2018-10-31 12:46:22',NULL),
	('th','ab.application.form.header','ข้อมูลแอปพลิเคชั่น',0,'app_builder',476,'2018-10-31 12:46:22',NULL),
	('th','ab.application.form.placeholderName','ชื่อแอปพลิเคชั่น',0,'app_builder',477,'2018-10-31 12:46:22',NULL),
	('th','ab.application.form.placeholderDescription','รายละเอียดแอปพลิเคชั่น',0,'app_builder',478,'2018-10-31 12:46:22',NULL),
	('th','ab.object.title','ข้อมูล',0,'app_builder',479,'2018-10-31 12:46:22',NULL),
	('th','ab.object.invalidName','ชื่อนี้ไม่ถูกต้อง',0,'app_builder',480,'2018-10-31 12:46:22',NULL),
	('th','ab.object.duplicateName','<b>{0}</b> มีซ้ำแล้ว',0,'app_builder',481,'2018-10-31 12:46:22',NULL),
	('th','ab.object.addNew','เพิ่มที่เก็บข้อมูลใหม่',0,'app_builder',482,'2018-10-31 12:46:22',NULL),
	('th','ab.object.menu','Object Menu',0,'app_builder',483,'2018-10-31 12:46:22',NULL),
	('th','ab.object.form.placeholderName','ชื่อที่เก็บข้อมูล',0,'app_builder',484,'2018-10-31 12:46:22',NULL),
	('th','ab.object.hideField','ซ่อนข้อมูล',0,'app_builder',485,'2018-10-31 12:46:22',NULL),
	('th','ab.object.filterField','กรองข้อมูล',0,'app_builder',486,'2018-10-31 12:46:22',NULL),
	('th','ab.object.sortField','เรียงลำดับ',0,'app_builder',487,'2018-10-31 12:46:22',NULL),
	('th','ab.object.editField','แก้ไขคอลัมน์',0,'app_builder',488,'2018-10-31 12:46:22',NULL),
	('th','ab.object.deleteField','ลบคอลัมน์',0,'app_builder',489,'2018-10-31 12:46:22',NULL),
	('th','ab.object.addNewRow','เพิ่มข้อมูลใหม่',0,'app_builder',490,'2018-10-31 12:46:22',NULL),
	('th','ab.object.couldNotDeleteField','ไม่สามารถลบได้',0,'app_builder',491,'2018-10-31 12:46:22',NULL),
	('th','ab.object.atLeastOneField','ออบเจ็คควรมีคอลัมน์อย่างน้อย 1',0,'app_builder',492,'2018-10-31 12:46:22',NULL),
	('th','ab.object.couldNotReorderField','ไม่สามารถเรียงคอลัมน์ได้',0,'app_builder',493,'2018-10-31 12:46:22',NULL),
	('th','ab.object.couldNotReorderFieldDetail','มีคอลัมน์ที่ถูกซ่อนไว้อยู่',0,'app_builder',494,'2018-10-31 12:46:22',NULL),
	('th','ab.object.selectConnectedData','เลือกข้อมูลที่เชื่อมต่อ',0,'app_builder',495,'2018-10-31 12:46:22',NULL),
	('th','ab.object.cannotConnectedDataTitle','ระบบไม่สามารถเชื่อมต่อข้อมูลนี้ได้',0,'app_builder',496,'2018-10-31 12:46:22',NULL),
	('th','ab.object.cannotConnectedDataDescription','ข้อมูลนี้ยังไม่ได้บันทึก คุณสามารถคลิ๊กที่ปุ่ม Synchronize เพื่อบันทึกข้อมูลนี้',0,'app_builder',497,'2018-10-31 12:46:22',NULL),
	('th','ab.object.noConnectedData','',0,'app_builder',498,'2018-10-31 12:46:22',NULL),
	('th','ab.object.connectToObjectName','(ลิ้งค์ไปยัง <b>{0}</b>)',0,'app_builder',499,'2018-10-31 12:46:22',NULL),
	('th','ab.object.delete.title','ลบคอลัมน์',0,'app_builder',500,'2018-10-31 12:46:22',NULL),
	('th','ab.object.delete.message','คุณต้องการลบ <b>{0}</b> หรือไม่?',0,'app_builder',501,'2018-10-31 12:46:22',NULL),
	('th','ab.object.deleteRow.title','ลบข้อมูล',0,'app_builder',502,'2018-10-31 12:46:22',NULL),
	('th','ab.object.deleteRow.message','คุณต้องการลบข้อมูลนี้หรือไม่?',0,'app_builder',503,'2018-10-31 12:46:22',NULL),
	('th','ab.object.toolbar.hideFields','ซ่อนข้อมูล',0,'app_builder',504,'2018-10-31 12:46:22',NULL),
	('th','ab.object.toolbar.filterFields','เพิ่มกรองข้อมูล',0,'app_builder',505,'2018-10-31 12:46:22',NULL),
	('th','ab.object.toolbar.sortFields','เรียงลำดับข้อมูล',0,'app_builder',506,'2018-10-31 12:46:22',NULL),
	('th','ab.object.toolbar.frozenColumns','ล็อคคอลัมน์',0,'app_builder',507,'2018-10-31 12:46:22',NULL),
	('th','ab.object.toolbar.defineLabel','กำหนดคำแสดง',0,'app_builder',508,'2018-10-31 12:46:22',NULL),
	('th','ab.object.toolbar.permission','สิทธิ์การเข้าถึง',0,'app_builder',509,'2018-10-31 12:46:22',NULL),
	('th','ab.object.toolbar.addFields','เพิ่มคอลัมน์ใหม่',0,'app_builder',510,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.chooseType','เลือกชนิดของข้อมูล...',0,'app_builder',511,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.fieldName','ชื่อฟิลด์',0,'app_builder',512,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.label','ชื่อแสดง',0,'app_builder',513,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.connectField','เชื่อมต่อกับข้อมูล',0,'app_builder',514,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.stringField','ข้อความ',0,'app_builder',515,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.textField','ข้อความยาว',0,'app_builder',516,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.numberField','ตัวเลข',0,'app_builder',517,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.dateField','วันที่',0,'app_builder',518,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.booleanField','เช็คบ็อกซ์',0,'app_builder',519,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.listField','ข้อมูลชุด',0,'app_builder',520,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.attachmentField','แนบไฟล์',0,'app_builder',521,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.defaultText','ค่าเริ่มต้น',0,'app_builder',522,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.defaultNumber','ค่าเริ่มต้น',0,'app_builder',523,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.supportMultilingual','รองรับหลายภาษา',0,'app_builder',524,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.connectToObject','เชื่อมต่อกับอ็อบเจ็คอื่น',0,'app_builder',525,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.connectToNewObject','เชื่อต่อกับอ็อบเจ็คใหม่',0,'app_builder',526,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.allowConnectMultipleValue','สามารถเพิ่มได้หลายข้อมูล',0,'app_builder',527,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.requireConnectedObjectTitle','จำเป็นต้องมีอ็อบเจ็ค',0,'app_builder',528,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.requireConnectedObjectDescription','กรุณาเลือกอ็อบเจ็คที่จะเชื่อมต่อ',0,'app_builder',529,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.textDescription','สามารถระบุข้อความได้หลายบันทัด',0,'app_builder',530,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.format','รูปแบบ',0,'app_builder',531,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.numberFormat','ตัวเลข',0,'app_builder',532,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.priceFormat','รูปแบบการเงิน',0,'app_builder',533,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.allowDecimalNumbers','สามารถเพิ่มทศนิยมได้',0,'app_builder',534,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.pickDate','เลือกวันที่จากปฏิทิน',0,'app_builder',535,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.includeTime','เพิ่มเวลา',0,'app_builder',536,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.booleanDescription','สามารถเลือกหรือไม่เลือกในเช็คบ็อกซ์ได้',0,'app_builder',537,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.listDescription','สามารถให้คุณกำหนดตัวเลือกไว้ก่อนได้',0,'app_builder',538,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.listOption','ตัวเลือก',0,'app_builder',539,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.listAddNewOption','เพิ่มตัวเลือก',0,'app_builder',540,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.requireListOptionTitle','กรุณากำหนดตัวเลือก',0,'app_builder',541,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.requireListOptionDescription','กรอกตัวเลือกอย่างน้อย 1 อัน',0,'app_builder',542,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.addNewField','เพิ่มคอลัมน์',0,'app_builder',543,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.registerTableWarning','กรุณาระบุ datatable ก่อน',0,'app_builder',544,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.duplicateFieldTitle','ชื่อคอลัมน์ของคุณซ้ำ',0,'app_builder',545,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.duplicateFieldDescription','กรุณาเปลี่ยนชื่อคอลัมน์ของคุณ',0,'app_builder',546,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.cannotUpdateFields','ไม่สามารถแก้ไขคอลัมน์ได้',0,'app_builder',547,'2018-10-31 12:46:22',NULL),
	('th','ab.add_fields.waitRestructureObjects','กรุณารอจนกว่าอ็อบเจ็คจะถูกสร้างใหม่เสร็จ',0,'app_builder',548,'2018-10-31 12:46:22',NULL),
	('th','ab.define_label.labelFormat','รูปแบบคำแสดง',0,'app_builder',549,'2018-10-31 12:46:22',NULL),
	('th','ab.define_label.selectFieldToGenerate','เลือกคอลัมน์เพื่อสร้างรูปแบบ',0,'app_builder',550,'2018-10-31 12:46:22',NULL),
	('th','ab.define_label.labelFields','คอลัมน์',0,'app_builder',551,'2018-10-31 12:46:22',NULL),
	('th','ab.define_label.loadError','ระบบไม่สามารถโหลดข้อมูลรูปแบบคำแสดงได้',0,'app_builder',552,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.and','และ',0,'app_builder',553,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.or','หรือ',0,'app_builder',554,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.addNewFilter','เพิ่มเงื่อนไขสำหรับกรองข้อมูล',0,'app_builder',555,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.containsCondition','มีอยู่ใน',0,'app_builder',556,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.notContainCondition','ไม่มีอยู่ใน',0,'app_builder',557,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.isCondition','เท่ากับ',0,'app_builder',558,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.isNotCondition','ไม่เท่ากับ',0,'app_builder',559,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.beforeCondition','ก่อน',0,'app_builder',560,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.afterCondition','หลัง',0,'app_builder',561,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.onOrBeforeCondition','ก่อนหรือเท่ากับ',0,'app_builder',562,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.onOrAfterCondition','หลังหรือเท่ากับ',0,'app_builder',563,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.equalCondition','=',0,'app_builder',564,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.notEqualCondition','≠',0,'app_builder',565,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.lessThanCondition','<',0,'app_builder',566,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.moreThanCondition','>',0,'app_builder',567,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.lessThanOrEqualCondition','≤',0,'app_builder',568,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.moreThanOrEqualCondition','≥',0,'app_builder',569,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.equalListCondition','เท่ากับ',0,'app_builder',570,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.notEqualListCondition','ไม่เท่ากับ',0,'app_builder',571,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.checkedCondition','ถูกเลือก',0,'app_builder',572,'2018-10-31 12:46:22',NULL),
	('th','ab.filter_fields.notCheckedCondition','ไม่ถูกเลือก',0,'app_builder',573,'2018-10-31 12:46:22',NULL),
	('th','ab.frozen_fields.clearAll','เคลียร์ทั้งหมด',0,'app_builder',574,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.addNewSort','เพิ่มเงื่อนไขการเรียงข้อมูล',0,'app_builder',575,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.selectField','เลือกคอลัมน์',0,'app_builder',576,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.textAsc','ก -> ฮ',0,'app_builder',577,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.textDesc','ฮ -> ก',0,'app_builder',578,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.dateAsc','ก่อน -> หลัง',0,'app_builder',579,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.dateDesc','หลัง -> ก่อน',0,'app_builder',580,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.numberAsc','1 -> 9',0,'app_builder',581,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.numberDesc','9 -> 1',0,'app_builder',582,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.booleanAsc','เช็ค -> ไม่เช็ค',0,'app_builder',583,'2018-10-31 12:46:22',NULL),
	('th','ab.sort_fields.booleanDesc','ไม่เช็ค -> เช็ค',0,'app_builder',584,'2018-10-31 12:46:22',NULL),
	('th','ab.visible_fields.showAll','โชว์ทั้งหมด',0,'app_builder',585,'2018-10-31 12:46:22',NULL),
	('th','ab.visible_fields.hideAll','ซ่อนทั้งหมด',0,'app_builder',586,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.page','หน้าแสดง',0,'app_builder',587,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.addNewPage','เพิ่มหน้าใหม่',0,'app_builder',588,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.placeholderPageName','ชื่อหน้า',0,'app_builder',589,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.delete.title','ลบหน้านี้',0,'app_builder',590,'2018-10-31 12:46:22',NULL),
	('th','ab.common.import','นำเข้า',0,'app_builder',591,'2018-10-31 12:46:22',NULL),
	('th','ab.common.export','ส่งออก',0,'app_builder',592,'2018-10-31 12:46:22',NULL),
	('th','ab.common.save.error','ระบบไม่สามารถบันทึก <b>{0}</b>',0,'app_builder',593,'2018-10-31 12:46:22',NULL),
	('th','ab.common.save.success','<b>{0}</b> ถูกบันทึกแล้ว',0,'app_builder',594,'2018-10-31 12:46:22',NULL),
	('th','ab.equation.date_year','[th] %s:Returns the year of a given date',0,'app_builder',595,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.delete.message','คุณต้องการลบ<b>{0}</b>หรือไม่',0,'app_builder',596,'2018-10-31 12:46:22',NULL),
	('th','ab.component.tab.addPage','[th] Add a tab below',0,'app_builder',597,'2018-10-31 12:46:22',NULL),
	('th','ab.component.tab.enterTabName','[th] Enter a tab name',0,'app_builder',598,'2018-10-31 12:46:22',NULL),
	('th','ab.component.tab.invalidTabName','[th] Tab name cannot be empty',0,'app_builder',599,'2018-10-31 12:46:22',NULL),
	('th','ab.component.tab.chooseIcon','[th] Choose an icon',0,'app_builder',600,'2018-10-31 12:46:22',NULL),
	('th','ab.component.tab.addTab','[th] Add Tab',0,'app_builder',601,'2018-10-31 12:46:22',NULL),
	('th','ab.validate.overMaxLength','ข้อมูลนี้ไม่ถูกต้อง',0,'app_builder',602,'2018-10-31 12:46:22',NULL),
	('th','ab.validate.overMaxLengthDescription','ข้อมูลไม่สามารถมีจำนวนอักขระมากกว่า #maxLength#',0,'app_builder',603,'2018-10-31 12:46:22',NULL),
	('th','ab.validate.invalidFormat','ข้อมูลนี้มีรูปแบบไม่ถูกต้อง',0,'app_builder',604,'2018-10-31 12:46:22',NULL),
	('th','ab.validate.invalidFormatDescription','ระบบไม่อนุญาตให้กรอกข้อมูลที่มีสัญลักษณ์อื่นๆ',0,'app_builder',605,'2018-10-31 12:46:22',NULL),
	('th','ab.application.invalidName','แอปพลิเคชั่นนี้ไม่ถูกต้อง',0,'app_builder',606,'2018-10-31 12:46:22',NULL),
	('th','ab.application.duplicateName','#appName# ซ้ำกับชื่อแอปพลิเคชั่นอื่น',0,'app_builder',607,'2018-10-31 12:46:22',NULL),
	('th','ab.components.label','[th] Label',0,'app_builder',608,'2018-10-31 12:46:22',NULL),
	('th','ab.component.label.text','[th] Text',0,'app_builder',609,'2018-10-31 12:46:22',NULL),
	('th','ab.component.label.textPlaceholder','[th] Text Placeholder',0,'app_builder',610,'2018-10-31 12:46:22',NULL),
	('th','ab.component.label.formatting','[th] format options:',0,'app_builder',611,'2018-10-31 12:46:22',NULL),
	('th','ab.component.label.formatting.normal','[th] normal',0,'app_builder',612,'2018-10-31 12:46:22',NULL),
	('th','ab.component.label.formatting.title','[th] title',0,'app_builder',613,'2018-10-31 12:46:22',NULL),
	('th','ab.component.label.formatting.description','[th] description',0,'app_builder',614,'2018-10-31 12:46:22',NULL),
	('th','ab.components.view','[th] View',0,'app_builder',615,'2018-10-31 12:46:22',NULL),
	('th','ab.validation.view.label.unique','[th] View label must be unique among peers.',0,'app_builder',616,'2018-10-31 12:46:22',NULL),
	('th','ab.components.view.dropHere','[th] Drop Component Here',0,'app_builder',617,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.component.confirmDeleteTitle','[th] Delete Component',0,'app_builder',618,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.component.confirmDeleteMessage','[th] Do you want to delete <b>{0}</b>?',0,'app_builder',619,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.properties','คุณสมบัติ',0,'app_builder',620,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.selectPage','[th] Select a Page to edit',0,'app_builder',621,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.viewModeBlock','[th] Block',0,'app_builder',622,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.viewModePreview','ภาพตัวอย่าง',0,'app_builder',623,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.page.parentList','[th] Parent Page',0,'app_builder',624,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.rootPage','[th] [Root Page]',0,'app_builder',625,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.components','[th] Components',0,'app_builder',626,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.noComponents','[th] No Components',0,'app_builder',627,'2018-10-31 12:46:22',NULL),
	('th','ab.dataField.common.headerLabel','[th] Section Title',0,'app_builder',628,'2018-10-31 12:46:22',NULL),
	('th','ab.dataField.common.headerLabelPlaceholder','[th] Section Name',0,'app_builder',629,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.quickPage','[th] Quick Page',0,'app_builder',630,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.blankPage','[th] Blank Page',0,'app_builder',631,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.title','ส่วนแสดงผล',0,'app_builder',632,'2018-10-31 12:46:22',NULL),
	('th','ab.object.selectObject','เลือกที่เก็บข้อมูล',0,'app_builder',633,'2018-10-31 12:46:22',NULL),
	('th','ab.common.none','[th] None',0,'app_builder',634,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.dataSource','[th] Data Source',0,'app_builder',635,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.object','[th] Object',0,'app_builder',636,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.linkedTo','[th] Linked To',0,'app_builder',637,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.linkField','[th] Link Field',0,'app_builder',638,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.text','[th] Text',0,'app_builder',639,'2018-10-31 12:46:22',NULL),
	('th','ab.abfield.labelPlaceholder','[th] label placeholder',0,'app_builder',640,'2018-10-31 12:46:22',NULL),
	('th','ab.component.form.text.useFormDefaults','[th] use form defaults',0,'app_builder',641,'2018-10-31 12:46:22',NULL),
	('th','ab.components.button','[th] Button',0,'app_builder',642,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form','[th] Form',0,'app_builder',643,'2018-10-31 12:46:22',NULL),
	('th','ab.components.checkbox','[th] Checkbox',0,'app_builder',644,'2018-10-31 12:46:22',NULL),
	('th','ab.components.custom','[th] Custom',0,'app_builder',645,'2018-10-31 12:46:22',NULL),
	('th','ab.components.detail','[th] Detail',0,'app_builder',646,'2018-10-31 12:46:22',NULL),
	('th','ab.components.dataview','[th] Data view',0,'app_builder',647,'2018-10-31 12:46:22',NULL),
	('th','ab.components.datepicker','[th] Date Picker',0,'app_builder',648,'2018-10-31 12:46:22',NULL),
	('th','ab.components.grid','[th] Grid',0,'app_builder',649,'2018-10-31 12:46:22',NULL),
	('th','ab.components.image','[th] Image',0,'app_builder',650,'2018-10-31 12:46:22',NULL),
	('th','ab.components.layout','[th] Layout',0,'app_builder',651,'2018-10-31 12:46:22',NULL),
	('th','ab.components.list','[th] List',0,'app_builder',652,'2018-10-31 12:46:22',NULL),
	('th','ab.components.menu','[th] Menu',0,'app_builder',653,'2018-10-31 12:46:22',NULL),
	('th','ab.components.number','[th] Number',0,'app_builder',654,'2018-10-31 12:46:22',NULL),
	('th','ab.components.selectsingle','[th] Single Select',0,'app_builder',655,'2018-10-31 12:46:22',NULL),
	('th','ab.components.tab','[th] Tab',0,'app_builder',656,'2018-10-31 12:46:22',NULL),
	('th','ab.components.text','[th] Text',0,'app_builder',657,'2018-10-31 12:46:22',NULL),
	('th','ab.components.textbox','[th] Textbox',0,'app_builder',658,'2018-10-31 12:46:22',NULL),
	('th','ab.components.tree','[th] Tree',0,'app_builder',659,'2018-10-31 12:46:22',NULL),
	('th','ab.components.pivot','[th] Pivot',0,'app_builder',660,'2018-10-31 12:46:22',NULL),
	('th','ab.object.list.setting','ตั้งค่า',0,'app_builder',661,'2018-10-31 12:46:22',NULL),
	('th','ab.object.list.search','ค้นหา',0,'app_builder',662,'2018-10-31 12:46:22',NULL),
	('th','ab.object.list.sort','จัดเรียง',0,'app_builder',663,'2018-10-31 12:46:22',NULL),
	('th','ab.object.list.sort.asc','ก -> ฮ',0,'app_builder',664,'2018-10-31 12:46:22',NULL),
	('th','ab.object.list.sort.desc','ฮ -> ก',0,'app_builder',665,'2018-10-31 12:46:22',NULL),
	('th','ab.object.list.group','จัดกลุ่ม',0,'app_builder',666,'2018-10-31 12:46:22',NULL),
	('th','ab.components.connect','[th] Connect',0,'app_builder',667,'2018-10-31 12:46:22',NULL),
	('th','ab.components.chart','[th] Chart',0,'app_builder',668,'2018-10-31 12:46:22',NULL),
	('th','ab.components.chart.pie','[th] Pie Chart',0,'app_builder',669,'2018-10-31 12:46:22',NULL),
	('th','ab.components.chart.bar','[th] Bar Chart',0,'app_builder',670,'2018-10-31 12:46:22',NULL),
	('th','ab.components.chart.line','[th] Line Chart',0,'app_builder',671,'2018-10-31 12:46:22',NULL),
	('th','ab.components.chart.area','[th] Area Chart',0,'app_builder',672,'2018-10-31 12:46:22',NULL),
	('th','ab.component.ruleaction.updateConnectedRecord','[th] Update Connected Record',0,'app_builder',673,'2018-10-31 12:46:22',NULL),
	('th','ab.ruleAction.Update.required','[th] A value is required',0,'app_builder',674,'2018-10-31 12:46:22',NULL),
	('th','ab.component.form.set','[th] Set',0,'app_builder',675,'2018-10-31 12:46:22',NULL),
	('th','ab.component.form.to','[th] To',0,'app_builder',676,'2018-10-31 12:46:22',NULL),
	('th','ab.ruleAction.UpdateConnected.selectField','[th] Select which connected object to update.',0,'app_builder',677,'2018-10-31 12:46:22',NULL),
	('th','ab.ruleAction.UpdateConnected.remoteCondition','[th] How to choose which object:',0,'app_builder',678,'2018-10-31 12:46:22',NULL),
	('th','ab.component.form.action','[th] Action',0,'app_builder',679,'2018-10-31 12:46:22',NULL),
	('th','ab.component.form.when','[th] When',0,'app_builder',680,'2018-10-31 12:46:22',NULL),
	('th','ab.component.form.values','[th] Values',0,'app_builder',681,'2018-10-31 12:46:22',NULL),
	('th','ab.interface.addWidget','[th] Add Widget',0,'app_builder',682,'2018-10-31 12:46:22',NULL),
	('th','ab.common.componentDropZone','[th] add widgets here',0,'app_builder',683,'2018-10-31 12:46:22',NULL),
	('th','ab.dataField.common.showIcon','[th] show icon?',0,'app_builder',684,'2018-10-31 12:46:22',NULL),
	('th','ab.dataField.common.columnNamePlaceholder','[th] Database field name',0,'app_builder',685,'2018-10-31 12:46:22',NULL),
	('th','ab.dataField.common.columnName','[th] Field Name',0,'app_builder',686,'2018-10-31 12:46:22',NULL),
	('th','ab.dataField.common.fieldLabelPlaceholder','[th] Label',0,'app_builder',687,'2018-10-31 12:46:22',NULL),
	('th','ab.dataField.common.fieldLabel','[th] Label',0,'app_builder',688,'2018-10-31 12:46:22',NULL),
	('th','ab.components.conditionalcontainer','[th] Conditional Container',0,'app_builder',689,'2018-10-31 12:46:22',NULL),
	('th','ab.components.container.columns','[th] Columns',0,'app_builder',690,'2018-10-31 12:46:22',NULL),
	('th','ab.components.page.type','[th] Type',0,'app_builder',691,'2018-10-31 12:46:22',NULL),
	('th','ab.component.selectsingle.type','[th] Type',0,'app_builder',692,'2018-10-31 12:46:22',NULL),
	('th','ab.component.textbox.type','[th] Type',0,'app_builder',693,'2018-10-31 12:46:22',NULL),
	('th','ab.dataField.file.fileType','[th] Type',0,'app_builder',694,'2018-10-31 12:46:22',NULL),
	('th','ab.components.page.popup','[th] Popup',0,'app_builder',695,'2018-10-31 12:46:22',NULL),
	('th','ab.components.page.page','[th] Page',0,'app_builder',696,'2018-10-31 12:46:22',NULL),
	('th','ab.components.common.showlabel','[th] Display Label',0,'app_builder',697,'2018-10-31 12:46:22',NULL),
	('th','ab.components.common.labelPosition','[th] Label Position',0,'app_builder',698,'2018-10-31 12:46:22',NULL),
	('th','ab.components.common.left','[th] Left',0,'app_builder',699,'2018-10-31 12:46:22',NULL),
	('th','ab.components.common.top','[th] Top',0,'app_builder',700,'2018-10-31 12:46:22',NULL),
	('th','ab.components.common.labelWidth','[th] Label Width',0,'app_builder',701,'2018-10-31 12:46:22',NULL),
	('th','ab.components.common.heigth','[th] Height',0,'app_builder',702,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.clearOnLoad','[th] Clear on load',0,'app_builder',703,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.rules','[th] Rules',0,'app_builder',704,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.submitRules','[th] Submit Rules',0,'app_builder',705,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.settings','[th] Settings',0,'app_builder',706,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.displayRules','[th] Display Rules',0,'app_builder',707,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.recordRules','[th] Record Rules',0,'app_builder',708,'2018-10-31 12:46:22',NULL),
	('th','ab.components.common.height','[th] Height',0,'app_builder',709,'2018-10-31 12:46:22',NULL),
	('th','ab.components.form.addNewRule','[th] Add new rule',0,'app_builder',710,'2018-10-31 12:46:22',NULL);

/*!40000 ALTER TABLE `site_multilingual_label` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_multilingual_language
# ------------------------------------------------------------

CREATE TABLE `site_multilingual_language` (
  `language_code` varchar(10) DEFAULT NULL,
  `language_label` longtext,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_multilingual_language` WRITE;
/*!40000 ALTER TABLE `site_multilingual_language` DISABLE KEYS */;

INSERT INTO `site_multilingual_language` (`language_code`, `language_label`, `id`, `createdAt`, `updatedAt`)
VALUES
	('en','English',1,'2018-10-31 12:46:19','2018-10-31 12:46:19'),
	('ko','Korean',2,'2018-10-31 12:46:19','2018-10-31 12:46:19'),
	('zh-hans','Chinese',3,'2018-10-31 12:46:19','2018-10-31 12:46:19'),
	('th','Thai',4,'2018-10-31 12:46:19','2018-10-31 12:46:19');

/*!40000 ALTER TABLE `site_multilingual_language` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_perm_actions
# ------------------------------------------------------------

CREATE TABLE `site_perm_actions` (
  `action_key` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `action_key` (`action_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_perm_actions` WRITE;
/*!40000 ALTER TABLE `site_perm_actions` DISABLE KEYS */;

INSERT INTO `site_perm_actions` (`action_key`, `id`, `createdAt`, `updatedAt`)
VALUES
	('adcore.admin',1,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('adcore.developer',2,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('site.auth.switcheroo',3,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('site.permission.action.translate',4,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('opsportal.view',5,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('opsportal.rbac.view',6,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('opsportal.opnavedit.view',7,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('appbuilder.designer.view',8,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('appbuilder.mobile.admin',9,'2018-10-31 12:46:14','2018-10-31 12:46:14');

/*!40000 ALTER TABLE `site_perm_actions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_perm_actions_trans
# ------------------------------------------------------------

CREATE TABLE `site_perm_actions_trans` (
  `action_description` longtext,
  `permissionaction` int(11) DEFAULT NULL,
  `language_code` varchar(10) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_perm_actions_trans` WRITE;
/*!40000 ALTER TABLE `site_perm_actions_trans` DISABLE KEYS */;

INSERT INTO `site_perm_actions_trans` (`action_description`, `permissionaction`, `language_code`, `id`, `createdAt`, `updatedAt`)
VALUES
	('Allows the user to administrate permissions in the system.',1,'en',1,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('Designates a User as a developer.',2,'en',2,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('Allows the user to switch between user accounts.',3,'en',3,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('Allows a User to translate Permission Action descriptions.',4,'en',4,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('Allows the user to access the opsportal.',5,'en',5,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('Allows the user to access the Roles And Permissions Tool.',6,'en',6,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('Allows the user to edit the Ops Portal Navigation.',7,'en',7,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('Allows the user to access the AppBuilder Designer tool.',8,'en',8,'2018-10-31 12:46:14','2018-10-31 12:46:14'),
	('Allow the user to configure Mobile Device settings.',9,'en',9,'2018-10-31 12:46:14','2018-10-31 12:46:14');

/*!40000 ALTER TABLE `site_perm_actions_trans` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_perm_role
# ------------------------------------------------------------

CREATE TABLE `site_perm_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_perm_role` WRITE;
/*!40000 ALTER TABLE `site_perm_role` DISABLE KEYS */;

INSERT INTO `site_perm_role` (`id`, `createdAt`, `updatedAt`)
VALUES
	(1,'2018-10-31 12:46:21','2018-10-31 12:46:29');

/*!40000 ALTER TABLE `site_perm_role` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_perm_role_trans
# ------------------------------------------------------------

CREATE TABLE `site_perm_role_trans` (
  `role` int(11) DEFAULT NULL,
  `language_code` varchar(10) DEFAULT NULL,
  `role_label` varchar(100) DEFAULT NULL,
  `role_description` longtext,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_label` (`role_label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_perm_role_trans` WRITE;
/*!40000 ALTER TABLE `site_perm_role_trans` DISABLE KEYS */;

INSERT INTO `site_perm_role_trans` (`role`, `language_code`, `role_label`, `role_description`, `id`, `createdAt`, `updatedAt`)
VALUES
	(1,'en','System Admin','System Wide Administrator Role',1,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'ko','[ko]System Admin','[ko]System Wide Administrator Role',2,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'zh-hans','[zh-hans]System Admin','[zh-hans]System Wide Administrator Role',3,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'th','[th]System Admin','[th]System Wide Administrator Role',4,'2018-10-31 12:46:21','2018-10-31 12:46:21');

/*!40000 ALTER TABLE `site_perm_role_trans` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_perm_scope
# ------------------------------------------------------------

CREATE TABLE `site_perm_scope` (
  `object` int(11) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `filter` longtext,
  `filterUI` longtext,
  `isGlobal` tinyint(1) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_perm_scope` WRITE;
/*!40000 ALTER TABLE `site_perm_scope` DISABLE KEYS */;

INSERT INTO `site_perm_scope` (`object`, `createdBy`, `filter`, `filterUI`, `isGlobal`, `id`, `createdAt`, `updatedAt`)
VALUES
	(1,NULL,NULL,'{\"condition\":\"AND\",\"rules\":[{\"id\":\"guid\",\"field\":\"guid\",\"type\":\"string\",\"input\":\"text\",\"operator\":\"is_not_empty\",\"value\":\"\"}],\"valid\":\"true\"}',NULL,1,'2018-10-31 12:46:21','2018-10-31 12:46:21');

/*!40000 ALTER TABLE `site_perm_scope` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_perm_scope_object
# ------------------------------------------------------------

CREATE TABLE `site_perm_scope_object` (
  `keyModel` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_perm_scope_object` WRITE;
/*!40000 ALTER TABLE `site_perm_scope_object` DISABLE KEYS */;

INSERT INTO `site_perm_scope_object` (`keyModel`, `id`, `createdAt`, `updatedAt`)
VALUES
	('siteuser',1,'2018-10-31 12:46:21','2018-10-31 12:46:21');

/*!40000 ALTER TABLE `site_perm_scope_object` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_perm_scope_object_trans
# ------------------------------------------------------------

CREATE TABLE `site_perm_scope_object_trans` (
  `permissionscopeobject` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `language_code` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_perm_scope_object_trans` WRITE;
/*!40000 ALTER TABLE `site_perm_scope_object_trans` DISABLE KEYS */;

INSERT INTO `site_perm_scope_object_trans` (`permissionscopeobject`, `name`, `language_code`, `id`, `createdAt`, `updatedAt`)
VALUES
	(1,'Site User','en',1,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'[ko]Site User','ko',2,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'[th]Site User','th',3,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'[zh-hans]Site User','zh-hans',4,'2018-10-31 12:46:21','2018-10-31 12:46:21');

/*!40000 ALTER TABLE `site_perm_scope_object_trans` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_perm_scope_trans
# ------------------------------------------------------------

CREATE TABLE `site_perm_scope_trans` (
  `permissionscope` int(11) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `language_code` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_perm_scope_trans` WRITE;
/*!40000 ALTER TABLE `site_perm_scope_trans` DISABLE KEYS */;

INSERT INTO `site_perm_scope_trans` (`permissionscope`, `label`, `description`, `language_code`, `id`, `createdAt`, `updatedAt`)
VALUES
	(1,'All Users',NULL,'en',1,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'[ko]All Users','[ko]','ko',2,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'[zh-hans]All Users','[zh-hans]','zh-hans',3,'2018-10-31 12:46:21','2018-10-31 12:46:21'),
	(1,'[th]All Users','[th]','th',4,'2018-10-31 12:46:21','2018-10-31 12:46:21');

/*!40000 ALTER TABLE `site_perm_scope_trans` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_permission
# ------------------------------------------------------------

CREATE TABLE `site_permission` (
  `user` int(11) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_permission` WRITE;
/*!40000 ALTER TABLE `site_permission` DISABLE KEYS */;

INSERT INTO `site_permission` (`user`, `role`, `enabled`, `id`, `createdAt`, `updatedAt`)
VALUES
	(1,1,1,1,'2018-10-31 12:46:21','2018-10-31 12:46:21');

/*!40000 ALTER TABLE `site_permission` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table site_switcheroo
# ------------------------------------------------------------

CREATE TABLE `site_switcheroo` (
  `username` varchar(255) DEFAULT NULL,
  `toUsername` varchar(255) DEFAULT NULL,
  `toGuid` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table site_user
# ------------------------------------------------------------

CREATE TABLE `site_user` (
  `uuid` varchar(255) DEFAULT NULL,
  `guid` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` longtext,
  `salt` varchar(64) DEFAULT NULL,
  `email` longtext,
  `isActive` int(1) DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `failedLogins` int(11) DEFAULT NULL,
  `languageCode` varchar(25) DEFAULT NULL,
  `ren_id` int(11) DEFAULT NULL,
  `sendEmailNotifications` int(1) DEFAULT NULL,
  `image_id` varchar(255) DEFAULT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `guid` (`guid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `site_user` WRITE;
/*!40000 ALTER TABLE `site_user` DISABLE KEYS */;

INSERT INTO `site_user` (`uuid`, `guid`, `username`, `password`, `salt`, `email`, `isActive`, `lastLogin`, `failedLogins`, `languageCode`, `ren_id`, `id`, `createdAt`, `updatedAt`)
VALUES
	('admin-uuid','admin','admin','e08dc5b971d374fcd5f230da2e04a614e74be2fc7bf68b52cdd63c7cd3ddd9f593941d71166794e3492995d5e975ce0b6ce1819880522a40c832d94fa2b2b6923f8524a2a783460c56bd3418e332d81c9779974e9224e91eca4adb026477889f46ed6afcb10f461bef74c037b6b491af343fbc80aefdad41268b87afd9d5791fbb06d894e20349e849e00f53be3241e5096f712bff7d84981bd04fca1fc695c794ae2d170cda9d3889b265980b52a4adc34433530359833abde4197c4860661844c0e9f67e38129e4c84e8c1d32c171aeb276ac8fba877634331596dff86d31dce5f4f2d530dd87a52a08b8a6a2fef8d4f525e9e2bfbbcd007c1963341339638c5488af11e05e0126921f52d18b076950e00ca9e8f14852dc49e9e45a410ab0d8e0795bc9528c955cc414cbff6599ccc6175c6202a3927de1b0cd5fa743bfd2ce5d534da6b453cc568dc8270631d89b1ed306c6dc6dfdc74881439905cf1f6d086f8f45e92d43c37b63b41fd31a74ee1e3ccf7be2b5ac29b81797d4c6179b544997b3cee026be49e7ad1e7f5be99125d441bac9cfba47885bcbfdc6416edfe6355af147d008f6bcb4f4312c4b10b60117897ed98d96bfd610f7bca0758c0f052ccf8cbe0fbe9f138c0b7d01cbf764a514e387916880b94c7f55ed10c36b903648152b9a62ac9f8a3e3121c296dd7ea22854aa63f6a4d455818e39a389a8c4913','65c3235deba74d197f01a8a3064850f4591adfd449cd716cb4d588bba2ad3608',NULL,1,'2018-10-31 12:46:19',0,'en',NULL,1,'2018-10-31 12:46:21','2018-10-31 12:46:21');

/*!40000 ALTER TABLE `site_user` ENABLE KEYS */;
UNLOCK TABLES;



# Dump of table User_UserForm
# ------------------------------------------------------------

CREATE TABLE `User_UserForm` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `User` text NOT NULL,
  `UserForm` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
